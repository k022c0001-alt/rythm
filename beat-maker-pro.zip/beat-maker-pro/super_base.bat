@echo off
chcp 65001 >nul
cd /d "%~dp0"

echo =========================================
echo Beat Maker Pro 起動スクリプト
echo =========================================

REM Pythonがインストールされているか確認
python --version >nul 2>&1
IF %ERRORLEVEL% EQU 0 (
    echo Pythonローカルサーバーを起動し、ブラウザで開きます。
    echo ※アプリを終了するには、この黒い画面の「X」を押して閉じてください。
    start http://localhost:8000
    python -m http.server 8000
) ELSE (
    echo Pythonが見つからないため、ブラウザで直接 index.html を開きます。
    echo ※ブラウザのセキュリティ制限により、一部の機能が動かない場合があります。
    start index.html
    pause
)