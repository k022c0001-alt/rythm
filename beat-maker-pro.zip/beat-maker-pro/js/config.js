const CONFIG = {
  ROWS: 21,  // ← 15から21に変更
  COLS: 16,
  TOTAL_PAGES: 4,
  
  DEFAULT_BPM: 120,
  MIN_BPM: 60,
  MAX_BPM: 200,
  
  DEFAULT_SWING: 0,
  MIN_SWING: 0,
  MAX_SWING: 50,
  
  SCHEDULE_AHEAD_TIME: 0.1,
  
  INSTRUMENTS: [
    // ========== ドラム系 ==========
    { name: 'Kick', emoji: '🥁', color: '#FF6B6B', isMelodic: false },
    { name: 'Snare', emoji: '🎵', color: '#4ECDC4', isMelodic: false },
    { name: 'HiHat', emoji: '🎩', color: '#FFE66D', isMelodic: false },
    { name: 'Tom', emoji: '🪘', color: '#FF8C42', isMelodic: false },
    { name: 'Rimshot', emoji: '🎯', color: '#A8DADC', isMelodic: false },
    { name: 'Cymbal', emoji: '🔔', color: '#F4A261', isMelodic: false },
    { name: 'Clap', emoji: '👏', color: '#E76F51', isMelodic: false },
    { name: 'Cowbell', emoji: '🔕', color: '#2A9D8F', isMelodic: false },
    
    // ========== メロディ・ベース系 ==========
    { name: 'Bass', emoji: '🔊', color: '#264653', isMelodic: true },
    { name: 'WobbleBass', emoji: '〰️', color: '#287271', isMelodic: true },
    { name: 'EGuitar', emoji: '🎸', color: '#E63946', isMelodic: true },
    { name: 'Zap', emoji: '⚡', color: '#F72585', isMelodic: true },
    
    // ========== 和楽器・民族楽器 ==========
    { name: 'Shinobue', emoji: '🎋', color: '#06FFA5', isMelodic: true },
    { name: 'Whistle', emoji: '🎐', color: '#C9F0FF', isMelodic: true },
    
    // ========== 優しい音源（新規追加） ==========
    { name: 'Bell', emoji: '🔔', color: '#B8E0FF', isMelodic: true },
    { name: 'Harp', emoji: '🎵', color: '#D4F1F4', isMelodic: true },
    { name: 'Flute', emoji: '🎶', color: '#A8DADC', isMelodic: true },
    
    // ========== 怖い音源（新規追加） ==========
    { name: 'DarkPad', emoji: '🌑', color: '#2D2D2D', isMelodic: true },
    { name: 'Scream', emoji: '😱', color: '#8B0000', isMelodic: false },
    { name: 'Drone', emoji: '👻', color: '#1A1A1A', isMelodic: true },
    
    // ========== エフェクト系 ==========
    { name: 'Glitch', emoji: '⚡', color: '#FF006E', isMelodic: false }
  ],
  
  NOTES: [
    { name: 'C', label: 'ド', ratio: 1.0 },
    { name: 'C#', label: 'ド♯', ratio: 1.0595 },
    { name: 'D', label: 'レ', ratio: 1.1225 },
    { name: 'D#', label: 'レ♯', ratio: 1.1892 },
    { name: 'E', label: 'ミ', ratio: 1.2599 },
    { name: 'F', label: 'ファ', ratio: 1.3348 },
    { name: 'F#', label: 'ファ♯', ratio: 1.4142 },
    { name: 'G', label: 'ソ', ratio: 1.4983 },
    { name: 'G#', label: 'ソ♯', ratio: 1.5874 },
    { name: 'A', label: 'ラ', ratio: 1.6818 },
    { name: 'A#', label: 'ラ♯', ratio: 1.7818 },
    { name: 'B', label: 'シ', ratio: 1.8877 },
    { name: 'C2', label: 'ド(高)', ratio: 2.0 }
  ]

  // デフォルト値

  

  
  // localStorage キー
  // STORAGE_KEY: 'beatMakerProData'
};