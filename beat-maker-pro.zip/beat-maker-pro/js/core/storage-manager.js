// ==========================================
// localStorage管理
// ==========================================

class StorageManager {
  constructor() {
    this.storageKey = CONFIG.STORAGE_KEY;
  }
  
  // データ保存
  save(data) {
    try {
      const jsonData = JSON.stringify(data);
      localStorage.setItem(this.storageKey, jsonData);
      return true;
    } catch (e) {
      console.error('保存エラー:', e);
      return false;
    }
  }
  
  // データ読込
  load() {
    try {
      const jsonData = localStorage.getItem(this.storageKey);
      return jsonData ? JSON.parse(jsonData) : null;
    } catch (e) {
      console.error('読込エラー:', e);
      return null;
    }
  }
  
  // 保存データの有無確認
  hasData() {
    return localStorage.getItem(this.storageKey) !== null;
  }
  
  // データ削除
  clear() {
    localStorage.removeItem(this.storageKey);
  }
  
  // 保存データ情報取得
  getInfo() {
    if (!this.hasData()) return null;
    
    const data = this.load();
    return {
      timestamp: data.timestamp || 'Unknown',
      bpm: data.bpm || CONFIG.DEFAULT_BPM,
      hasGrid: data.grid && data.grid.length > 0
    };
  }
}