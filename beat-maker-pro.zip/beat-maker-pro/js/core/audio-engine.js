// ==========================================
// 音源生成とエフェクト処理
// ==========================================

class AudioEngine {
  constructor() {
    this.audioContext = new (window.AudioContext || window.webkitAudioContext)();
    this.masterGain = this.audioContext.createGain();
    this.masterGain.gain.value = 0.7;
    
    this.effectChain = {};
    this.setupEffectChain();
  }
  
  // エフェクトチェーン構築

  setupEffectChain() {
    // Delayノード
    this.effectChain.delay = this.audioContext.createDelay(5.0);
    this.effectChain.delay.delayTime.value = 0;
    
    // Feedbackゲイン（初期値を0にする = 重要！）
    this.effectChain.delayFeedback = this.audioContext.createGain();
    this.effectChain.delayFeedback.gain.value = 0;
    
    // Delay Mixゲイン（ウェット信号）
    this.effectChain.delayMix = this.audioContext.createGain();
    this.effectChain.delayMix.gain.value = 0;
    
    // Dry Mixゲイン（ドライ信号）
    this.effectChain.dryMix = this.audioContext.createGain();
    this.effectChain.dryMix.gain.value = 1.0;
    
    // Pitchゲイン（入力）
    this.effectChain.pitch = this.audioContext.createGain();
    this.effectChain.pitch.gain.value = 1.0;
    
    // Decayゲイン（最終出力前）
    this.effectChain.decay = this.audioContext.createGain();
    this.effectChain.decay.gain.value = 1.0;
    
    // ==========================================
    // 配線: 正しいシグナルフロー
    // ==========================================
    
    // 【入力】
    // 各楽器 → pitch
    
    // 【ドライパス】
    // pitch → dryMix → decay
    this.effectChain.pitch.connect(this.effectChain.dryMix);
    this.effectChain.dryMix.connect(this.effectChain.decay);
    
    // 【ウェットパス（Delay）】
    // pitch → delay → delayMix → decay
    this.effectChain.pitch.connect(this.effectChain.delay);
    this.effectChain.delay.connect(this.effectChain.delayMix);
    this.effectChain.delayMix.connect(this.effectChain.decay);
    
    // 【フィードバックループ】
    // delay → delayFeedback → delay
    this.effectChain.delay.connect(this.effectChain.delayFeedback);
    this.effectChain.delayFeedback.connect(this.effectChain.delay);
    
    // 【マスター出力】
    // decay → masterGain → destination
    this.effectChain.decay.connect(this.masterGain);
    this.masterGain.connect(this.audioContext.destination);
  }
  
  
  // Kick ドラム
  playKick(time, trackSettings = { pitch: 1.0, volume: 1.0 }) {
    const osc = this.audioContext.createOscillator();
    const gain = this.audioContext.createGain();
    
    osc.frequency.setValueAtTime(150 * trackSettings.pitch, time);
    osc.frequency.exponentialRampToValueAtTime(0.01 * trackSettings.pitch, time + 0.5);
    
    gain.gain.setValueAtTime(1 * trackSettings.volume, time);
    gain.gain.exponentialRampToValueAtTime(0.01 * trackSettings.volume, time + 0.5);
    
    osc.connect(gain);
    gain.connect(this.effectChain.pitch);
    
    osc.start(time);
    osc.stop(time + 0.5);
  }
  
  // Snare ドラム
  playSnare(time, trackSettings = { pitch: 1.0, volume: 1.0 }) {
    const noise = this.audioContext.createBufferSource();
    const noiseBuffer = this.audioContext.createBuffer(1, this.audioContext.sampleRate * 0.2, this.audioContext.sampleRate);
    const output = noiseBuffer.getChannelData(0);
    
    for (let i = 0; i < noiseBuffer.length; i++) {
      output[i] = Math.random() * 2 - 1;
    }
    
    noise.buffer = noiseBuffer;
    noise.playbackRate.value = trackSettings.pitch;
    
    const noiseFilter = this.audioContext.createBiquadFilter();
    noiseFilter.type = 'highpass';
    noiseFilter.frequency.value = 1000 * trackSettings.pitch;
    
    const noiseEnvelope = this.audioContext.createGain();
    noiseEnvelope.gain.setValueAtTime(1 * trackSettings.volume, time);
    noiseEnvelope.gain.exponentialRampToValueAtTime(0.01 * trackSettings.volume, time + 0.2);
    
    noise.connect(noiseFilter);
    noiseFilter.connect(noiseEnvelope);
    noiseEnvelope.connect(this.effectChain.pitch);
    
    noise.start(time);
    noise.stop(time + 0.2);
    
    const osc = this.audioContext.createOscillator();
    osc.type = 'triangle';
    const oscGain = this.audioContext.createGain();
    osc.frequency.setValueAtTime(100 * trackSettings.pitch, time);
    oscGain.gain.setValueAtTime(0.7 * trackSettings.volume, time);
    oscGain.gain.exponentialRampToValueAtTime(0.01 * trackSettings.volume, time + 0.1);
    
    osc.connect(oscGain);
    oscGain.connect(this.effectChain.pitch);
    osc.start(time);
    osc.stop(time + 0.1);
  }
  
  // HiHat
  playHiHat(time, trackSettings = { pitch: 1.0, volume: 1.0 }) {
    const noise = this.audioContext.createBufferSource();
    const noiseBuffer = this.audioContext.createBuffer(1, this.audioContext.sampleRate * 0.05, this.audioContext.sampleRate);
    const output = noiseBuffer.getChannelData(0);
    
    for (let i = 0; i < noiseBuffer.length; i++) {
      output[i] = Math.random() * 2 - 1;
    }
    
    noise.buffer = noiseBuffer;
    noise.playbackRate.value = trackSettings.pitch;
    
    const bandpass = this.audioContext.createBiquadFilter();
    bandpass.type = 'bandpass';
    bandpass.frequency.value = 10000 * trackSettings.pitch;
    
    const highpass = this.audioContext.createBiquadFilter();
    highpass.type = 'highpass';
    highpass.frequency.value = 7000 * trackSettings.pitch;
    
    const envelope = this.audioContext.createGain();
    envelope.gain.setValueAtTime(0.5 * trackSettings.volume, time);
    envelope.gain.exponentialRampToValueAtTime(0.01 * trackSettings.volume, time + 0.05);
    
    noise.connect(bandpass);
    bandpass.connect(highpass);
    highpass.connect(envelope);
    envelope.connect(this.effectChain.pitch);
    
    noise.start(time);
    noise.stop(time + 0.05);
  }
  
  // Zap シンセサイザー
  playZap(time, trackSettings = { pitch: 1.0, volume: 1.0 }) {
    const osc = this.audioContext.createOscillator();
    osc.type = 'sawtooth';
    const gain = this.audioContext.createGain();
    
    osc.frequency.setValueAtTime(1000, time);
    osc.frequency.exponentialRampToValueAtTime(100, time + 0.1);
    
    gain.gain.setValueAtTime(0.3, time);
    gain.gain.exponentialRampToValueAtTime(0.01, time + 0.1);
    
    osc.connect(gain);
    gain.connect(this.effectChain.pitch);
    
    osc.start(time);
    osc.stop(time + 0.1);
  }
  
  // Cymbal シンバル（新規追加）
  playCymbal(time, trackSettings = { pitch: 1.0, volume: 1.0 }) {
    // ノイズ生成（シンバルの金属的な音）
    const bufferSize = this.audioContext.sampleRate * 2; // 2秒分
    const buffer = this.audioContext.createBuffer(1, bufferSize, this.audioContext.sampleRate);
    const output = buffer.getChannelData(0);
    
    // ホワイトノイズ生成
    for (let i = 0; i < bufferSize; i++) {
      output[i] = Math.random() * 2 - 1;
    }
    
    const noise = this.audioContext.createBufferSource();
    noise.buffer = buffer;
    
    // ハイパスフィルター（低音をカット→金属的な響き）
    const highpass = this.audioContext.createBiquadFilter();
    highpass.type = 'highpass';
    highpass.frequency.value = 7000; // 7kHz以上だけ通す
    
    // バンドパスフィルター（特定周波数を強調）
    const bandpass = this.audioContext.createBiquadFilter();
    bandpass.type = 'bandpass';
    bandpass.frequency.value = 10000; // 10kHz付近を強調
    bandpass.Q.value = 1;
    
    // エンベロープ（音量の時間変化）
    const envelope = this.audioContext.createGain();
    envelope.gain.setValueAtTime(0.3, time);
    envelope.gain.exponentialRampToValueAtTime(0.01, time + 0.5);
    envelope.gain.exponentialRampToValueAtTime(0.001, time + 2);
    
    // 接続: noise → highpass → bandpass → envelope → エフェクト
    noise.connect(highpass);
    highpass.connect(bandpass);
    bandpass.connect(envelope);
    envelope.connect(this.effectChain.pitch);
    
    // 再生
    noise.start(time);
    noise.stop(time + 2); // 2秒後に停止
  }
  
  // Clap クラップ（手拍子）
  playClap(time, trackSettings = { pitch: 1.0, volume: 1.0 }) {
    // 複数の短いノイズバーストで手拍子の音を再現
    const createClapNoise = (startTime, duration) => {
      const bufferSize = this.audioContext.sampleRate * duration;
      const buffer = this.audioContext.createBuffer(1, bufferSize, this.audioContext.sampleRate);
      const output = buffer.getChannelData(0);
      
      for (let i = 0; i < bufferSize; i++) {
        output[i] = Math.random() * 2 - 1;
      }
      
      const noise = this.audioContext.createBufferSource();
      noise.buffer = buffer;
      
      // バンドパスフィルター（中高音域を強調）
      const bandpass = this.audioContext.createBiquadFilter();
      bandpass.type = 'bandpass';
      bandpass.frequency.value = 2500;
      bandpass.Q.value = 1;
      
      // エンベロープ
      const envelope = this.audioContext.createGain();
      envelope.gain.setValueAtTime(0.5, startTime);
      envelope.gain.exponentialRampToValueAtTime(0.01, startTime + duration);
      
      noise.connect(bandpass);
      bandpass.connect(envelope);
      envelope.connect(this.effectChain.pitch);
      
      noise.start(startTime);
      noise.stop(startTime + duration);
    };
    
    // 3つの短いノイズバーストを少しずつずらして再生（リアルな手拍子感）
    createClapNoise(time, 0.01);
    createClapNoise(time + 0.01, 0.01);
    createClapNoise(time + 0.02, 0.03);
  }
  
  // Tom タム
  playTom(time, trackSettings = { pitch: 1.0, volume: 1.0 }) {
    const osc = this.audioContext.createOscillator();
    osc.type = 'sine';
    const gain = this.audioContext.createGain();
    
    // 周波数を高→低へ急激に変化させる（タムの特徴）
    osc.frequency.setValueAtTime(200, time);
    osc.frequency.exponentialRampToValueAtTime(80, time + 0.15);
    
    // エンベロープ（減衰カーブ）
    gain.gain.setValueAtTime(1, time);
    gain.gain.exponentialRampToValueAtTime(0.01, time + 0.4);
    
    // ノイズを少し混ぜて質感を出す
    const noiseBuffer = this.audioContext.createBuffer(1, this.audioContext.sampleRate * 0.05, this.audioContext.sampleRate);
    const noiseOutput = noiseBuffer.getChannelData(0);
    for (let i = 0; i < noiseBuffer.length; i++) {
      noiseOutput[i] = Math.random() * 2 - 1;
    }
    
    const noise = this.audioContext.createBufferSource();
    noise.buffer = noiseBuffer;
    
    const noiseGain = this.audioContext.createGain();
    noiseGain.gain.setValueAtTime(0.1, time);
    noiseGain.gain.exponentialRampToValueAtTime(0.01, time + 0.05);
    
    // 接続
    osc.connect(gain);
    gain.connect(this.effectChain.pitch);
    
    noise.connect(noiseGain);
    noiseGain.connect(this.effectChain.pitch);
    
    // 再生
    osc.start(time);
    osc.stop(time + 0.4);
    noise.start(time);
    noise.stop(time + 0.05);
  }
  
  // Whistle 珍しい笛の音（サンポーニャ風）
  playWhistle(time, trackSettings = { pitch: 1.0, volume: 1.0 }) {
    // 複数のサイン波を重ねて倍音を作る（笛の特徴）
    const createTone = (freq, gainValue, duration) => {
      const osc = this.audioContext.createOscillator();
      osc.type = 'sine';
      osc.frequency.value = freq;
      
      const gain = this.audioContext.createGain();
      gain.gain.setValueAtTime(0, time);
      gain.gain.linearRampToValueAtTime(gainValue, time + 0.02); // アタック
      gain.gain.setValueAtTime(gainValue, time + duration - 0.05);
      gain.gain.linearRampToValueAtTime(0, time + duration); // リリース
      
      osc.connect(gain);
      gain.connect(this.effectChain.pitch);
      
      osc.start(time);
      osc.stop(time + duration);
    };
    
    // 基音 + 倍音で豊かな笛の音を作る
    const fundamental = 880; // A5（高めの音）
    const duration = 0.3;
    
    createTone(fundamental, 0.3, duration);           // 基音
    createTone(fundamental * 2, 0.15, duration);      // 2倍音
    createTone(fundamental * 3, 0.08, duration);      // 3倍音
    createTone(fundamental * 1.5, 0.1, duration);     // 5度上（珍しい響き）
    
    // ビブラート効果（少し音程を揺らす）
    const vibrato = this.audioContext.createOscillator();
    vibrato.frequency.value = 5; // 5Hzでゆらゆら
    const vibratoGain = this.audioContext.createGain();
    vibratoGain.gain.value = 10; // 音程の揺れ幅
    
    vibrato.connect(vibratoGain);
    vibrato.start(time);
    vibrato.stop(time + duration);
  }
  
  // Bass ベース
  playBass(time, trackSettings = { pitch: 1.0, volume: 1.0 }) {
    const osc = this.audioContext.createOscillator();
    osc.type = 'sawtooth'; // のこぎり波で太い音
    const gain = this.audioContext.createGain();
    
    // 低音域（60Hz = C2）
    osc.frequency.setValueAtTime(60, time);
    osc.frequency.exponentialRampToValueAtTime(55, time + 0.2); // わずかに下がる
    
    // エンベロープ
    gain.gain.setValueAtTime(0.6, time);
    gain.gain.setValueAtTime(0.6, time + 0.1);
    gain.gain.exponentialRampToValueAtTime(0.01, time + 0.5);
    
    // ローパスフィルター（高音をカットして丸い音に）
    const lowpass = this.audioContext.createBiquadFilter();
    lowpass.type = 'lowpass';
    lowpass.frequency.value = 300;
    lowpass.Q.value = 1;
    
    // 接続
    osc.connect(lowpass);
    lowpass.connect(gain);
    gain.connect(this.effectChain.pitch);
    
    osc.start(time);
    osc.stop(time + 0.5);
  }
  
  // Rimshot リムショット
  playRimshot(time, trackSettings = { pitch: 1.0, volume: 1.0 }) {
    // 高周波のノイズバースト + 短いトーン
    const noiseBuffer = this.audioContext.createBuffer(1, this.audioContext.sampleRate * 0.01, this.audioContext.sampleRate);
    const output = noiseBuffer.getChannelData(0);
    
    for (let i = 0; i < noiseBuffer.length; i++) {
      output[i] = Math.random() * 2 - 1;
    }
    
    const noise = this.audioContext.createBufferSource();
    noise.buffer = noiseBuffer;
    
    // ハイパスフィルター（高音だけ通す）
    const highpass = this.audioContext.createBiquadFilter();
    highpass.type = 'highpass';
    highpass.frequency.value = 3000;
    
    const noiseGain = this.audioContext.createGain();
    noiseGain.gain.setValueAtTime(0.8, time);
    noiseGain.gain.exponentialRampToValueAtTime(0.01, time + 0.05);
    
    noise.connect(highpass);
    highpass.connect(noiseGain);
    noiseGain.connect(this.effectChain.pitch);
    
    // トーン成分（カチッという音）
    const osc = this.audioContext.createOscillator();
    osc.type = 'triangle';
    osc.frequency.value = 400;
    
    const oscGain = this.audioContext.createGain();
    oscGain.gain.setValueAtTime(0.5, time);
    oscGain.gain.exponentialRampToValueAtTime(0.01, time + 0.03);
    
    osc.connect(oscGain);
    oscGain.connect(this.effectChain.pitch);
    
    // 再生
    noise.start(time);
    noise.stop(time + 0.05);
    osc.start(time);
    osc.stop(time + 0.03);
  }
  
  // Cowbell カウベル
  playCowbell(time, trackSettings = { pitch: 1.0, volume: 1.0 }) {
    // 2つの周波数を組み合わせて金属的な音を作る
    const createMetallicTone = (freq1, freq2) => {
      const osc1 = this.audioContext.createOscillator();
      const osc2 = this.audioContext.createOscillator();
      
      osc1.type = 'square';
      osc2.type = 'square';
      osc1.frequency.value = freq1;
      osc2.frequency.value = freq2;
      
      const gain = this.audioContext.createGain();
      gain.gain.setValueAtTime(0.4, time);
      gain.gain.exponentialRampToValueAtTime(0.01, time + 0.3);
      
      // バンドパスフィルター（中高音域を強調）
      const bandpass = this.audioContext.createBiquadFilter();
      bandpass.type = 'bandpass';
      bandpass.frequency.value = 800;
      bandpass.Q.value = 2;
      
      osc1.connect(bandpass);
      osc2.connect(bandpass);
      bandpass.connect(gain);
      gain.connect(this.effectChain.pitch);
      
      osc1.start(time);
      osc2.start(time);
      osc1.stop(time + 0.3);
      osc2.stop(time + 0.3);
    };
    
    // 不協和な2つの周波数でカウベルの「カーン」という音
    createMetallicTone(800, 540); // 800Hzと540Hz（不協和音程）
  }
  
  // Shinobue しの笛（日本の伝統的な竹笛）
  playShinobue(time, trackSettings = { pitch: 1.0, volume: 1.0 }) {
    // しの笛は倍音が少なく、柔らかい音色が特徴
    const fundamental = 1760 * trackSettings.pitch; // A6（高音域）
    const duration = 0.4;
    
    // サイン波で純粋な音を作る
    const osc = this.audioContext.createOscillator();
    osc.type = 'sine';
    osc.frequency.value = fundamental;
    
    // わずかな2倍音を混ぜる（しの笛の特徴）
    const osc2 = this.audioContext.createOscillator();
    osc2.type = 'sine';
    osc2.frequency.value = fundamental * 2;
    
    const gain = this.audioContext.createGain();
    const gain2 = this.audioContext.createGain();
    
    // エンベロープ（柔らかいアタック、緩やかなリリース）
    gain.gain.setValueAtTime(0, time);
    gain.gain.linearRampToValueAtTime(0.3 * trackSettings.volume, time + 0.05);
    gain.gain.setValueAtTime(0.3 * trackSettings.volume, time + duration - 0.1);
    gain.gain.linearRampToValueAtTime(0, time + duration);
    
    gain2.gain.setValueAtTime(0, time);
    gain2.gain.linearRampToValueAtTime(0.1 * trackSettings.volume, time + 0.05);
    gain2.gain.setValueAtTime(0.1 * trackSettings.volume, time + duration - 0.1);
    gain2.gain.linearRampToValueAtTime(0, time + duration);
    
    // わずかなビブラート（息の揺らぎ）
    const vibrato = this.audioContext.createOscillator();
    vibrato.frequency.value = 4; // 4Hzでゆっくり揺らす
    const vibratoGain = this.audioContext.createGain();
    vibratoGain.gain.value = 5 * trackSettings.pitch;
    
    vibrato.connect(vibratoGain);
    vibratoGain.connect(osc.frequency);
    
    // 接続
    osc.connect(gain);
    osc2.connect(gain2);
    gain.connect(this.effectChain.pitch);
    gain2.connect(this.effectChain.pitch);
    
    // 再生
    vibrato.start(time);
    osc.start(time);
    osc2.start(time);
    vibrato.stop(time + duration);
    osc.stop(time + duration);
    osc2.stop(time + duration);
  }
  
  // Glitch グリッチ（デジタルノイズ）
  playGlitch(time, trackSettings = { pitch: 1.0, volume: 1.0 }) {
    // 短いランダムなデジタルノイズバースト
    const bufferSize = this.audioContext.sampleRate * 0.05;
    const buffer = this.audioContext.createBuffer(1, bufferSize, this.audioContext.sampleRate);
    const output = buffer.getChannelData(0);
    
    // ランダムなビットクラッシュ効果
    for (let i = 0; i < bufferSize; i++) {
      // サンプル＆ホールド効果（デジタル感）
      if (i % 8 === 0) {
        output[i] = Math.random() * 2 - 1;
      } else {
        output[i] = output[i - 1];
      }
    }
    
    const noise = this.audioContext.createBufferSource();
    noise.buffer = buffer;
    noise.playbackRate.value = (1 + Math.random() * 2) * trackSettings.pitch;
    
    // ランダムなフィルター
    const filter = this.audioContext.createBiquadFilter();
    filter.type = Math.random() > 0.5 ? 'highpass' : 'lowpass';
    filter.frequency.value = (500 + Math.random() * 5000) * trackSettings.pitch;
    
    const envelope = this.audioContext.createGain();
    envelope.gain.setValueAtTime(0.6 * trackSettings.volume, time);
    envelope.gain.exponentialRampToValueAtTime(0.01 * trackSettings.volume, time + 0.05);
    
    // 接続
    noise.connect(filter);
    filter.connect(envelope);
    envelope.connect(this.effectChain.pitch);
    
    noise.start(time);
    noise.stop(time + 0.05);
  }
  
  // WobbleBass ウォブルベース
  playWobbleBass(time, trackSettings = { pitch: 1.0, volume: 1.0 }) {
    const osc = this.audioContext.createOscillator();
    osc.type = 'sawtooth';
    osc.frequency.value = 55 * trackSettings.pitch; // A1（超低音）
    
    const gain = this.audioContext.createGain();
    gain.gain.setValueAtTime(0.7 * trackSettings.volume, time);
    gain.gain.setValueAtTime(0.7 * trackSettings.volume, time + 0.3);
    gain.gain.exponentialRampToValueAtTime(0.01 * trackSettings.volume, time + 0.6);
    
    // ワウワウ効果のためのローパスフィルター
    const filter = this.audioContext.createBiquadFilter();
    filter.type = 'lowpass';
    filter.Q.value = 10; // 共振を強く
    
    // LFO（低周波オシレーター）でフィルターを揺らす
    const lfo = this.audioContext.createOscillator();
    lfo.frequency.value = 6; // 6Hzで「ワウワウ」
    
    const lfoGain = this.audioContext.createGain();
    lfoGain.gain.value = 800 * trackSettings.pitch;
    
    lfo.connect(lfoGain);
    lfoGain.connect(filter.frequency);
    
    // フィルターの基準周波数
    filter.frequency.value = 200 * trackSettings.pitch;
    
    // 接続
    osc.connect(filter);
    filter.connect(gain);
    gain.connect(this.effectChain.pitch);
    
    // 再生
    lfo.start(time);
    osc.start(time);
    lfo.stop(time + 0.6);
    osc.stop(time + 0.6);
  }
  
  // EGuitar エレクトリックギター（ディストーション）
  playEGuitar(time, trackSettings = { pitch: 1.0, volume: 1.0 }) {
    // パワーコード風（基音＋5度上）
    const fundamental = 196 * trackSettings.pitch; // G3
    const fifth = fundamental * 1.5; // D4（完全5度上）
    
    // ディストーションカーブを作成
    const makeDistortionCurve = (amount = 50) => {
      const samples = 44100;
      const curve = new Float32Array(samples);
      const deg = Math.PI / 180;
      
      for (let i = 0; i < samples; i++) {
        const x = (i * 2) / samples - 1;
        curve[i] = ((3 + amount) * x * 20 * deg) / (Math.PI + amount * Math.abs(x));
      }
      return curve;
    };
    
    // オシレーター（基音）
    const osc1 = this.audioContext.createOscillator();
    osc1.type = 'sawtooth';
    osc1.frequency.value = fundamental;
    
    // オシレーター（5度上）
    const osc2 = this.audioContext.createOscillator();
    osc2.type = 'sawtooth';
    osc2.frequency.value = fifth;
    
    // わずかなデチューンでリアルなギター感
    const osc3 = this.audioContext.createOscillator();
    osc3.type = 'sawtooth';
    osc3.frequency.value = fundamental * 1.01;
    
    // ミキサー
    const preGain = this.audioContext.createGain();
    preGain.gain.value = 1.5; // ディストーション前のゲインブースト
    
    // ディストーション（WaveShaperNode）
    const distortion = this.audioContext.createWaveShaper();
    distortion.curve = makeDistortionCurve(100);
    distortion.oversample = '4x';
    
    // ローパスフィルター（高音をカットして丸い音に）
    const lowpass = this.audioContext.createBiquadFilter();
    lowpass.type = 'lowpass';
    lowpass.frequency.value = 2000 * trackSettings.pitch;
    lowpass.Q.value = 1;
    
    // ハイパスフィルター（低音ノイズをカット）
    const highpass = this.audioContext.createBiquadFilter();
    highpass.type = 'highpass';
    highpass.frequency.value = 80;
    
    // エンベロープ（ピッキング感）
    const envelope = this.audioContext.createGain();
    envelope.gain.setValueAtTime(0, time);
    envelope.gain.linearRampToValueAtTime(0.6 * trackSettings.volume, time + 0.01); // 急激なアタック
    envelope.gain.setValueAtTime(0.5 * trackSettings.volume, time + 0.1);
    envelope.gain.exponentialRampToValueAtTime(0.01 * trackSettings.volume, time + 0.5);
    
    // 接続チェーン: osc → preGain → distortion → lowpass → highpass → envelope
    osc1.connect(preGain);
    osc2.connect(preGain);
    osc3.connect(preGain);
    preGain.connect(distortion);
    distortion.connect(lowpass);
    lowpass.connect(highpass);
    highpass.connect(envelope);
    envelope.connect(this.effectChain.pitch);
    
    // 再生
    osc1.start(time);
    osc2.start(time);
    osc3.start(time);
    osc1.stop(time + 0.5);
    osc2.stop(time + 0.5);
    osc3.stop(time + 0.5);
  }
  
  // 楽器演奏の振り分け
  playInstrument(instrument, time, trackSettings = { pitch: 1.0, volume: 1.0 }) {
    switch (instrument) {
      case 'Kick':
        this.playKick(time, trackSettings);
        break;
      case 'Snare':
        this.playSnare(time, trackSettings);
        break;
      case 'HiHat':
        this.playHiHat(time, trackSettings);
        break;
      case 'Zap':
        this.playZap(time, trackSettings);
        break;
      case 'Cymbal':
        this.playCymbal(time, trackSettings);
        break;
      case 'Clap':
        this.playClap(time, trackSettings);
        break;
      case 'Tom':
        this.playTom(time, trackSettings);
        break;
      case 'Whistle':
        this.playWhistle(time, trackSettings);
        break;
      case 'Bass':
        this.playBass(time, trackSettings);
        break;
      case 'Rimshot':
        this.playRimshot(time, trackSettings);
        break;
      case 'Cowbell':
        this.playCowbell(time, trackSettings);
        break;
      case 'Shinobue':
        this.playShinobue(time, trackSettings);
        break;
      case 'Glitch':
        this.playGlitch(time, trackSettings);
        break;
      case 'WobbleBass':
        this.playWobbleBass(time, trackSettings);
        break;
      case 'EGuitar':
        this.playEGuitar(time, trackSettings);
        break;
    }
  }
  
  // エフェクトパラメータ設定
  setDelayTime(value) {
    this.effectChain.delay.delayTime.value = value;
  }
  
  setDelayFeedback(value) {
    this.effectChain.delayFeedback.gain.value = value;
  }
  
  setDelayMix(value) {
    this.effectChain.delayMix.gain.value = value;
  }
  
  setDecay(value) {
    this.effectChain.decay.gain.value = value;
  }
  // ==========================================
// 新規音源追加（優しい音 & 怖い音）
// audio-engine.js に追加するコード
// ==========================================
// ==========================================
// 新音源コード（完全修正版・確実に音が出る）
// ==========================================

// ★★★ audio-engine.js の AudioEngine クラス内にこれらのメソッドを追加 ★★★
// ==========================================
// 新音源コード（完全修正版・既存のaudio-engine.jsに対応）
// ==========================================

// ★★★ 以下のメソッドを audio-engine.js の AudioEngine クラス内に追加 ★★★
// ★★★ playInstrument() の switch文にも case を追加してください ★★★

// ==========================================
// 優しい音源グループ
// ==========================================

// Bell ベル（優しい鐘の音）
playBell(time, trackSettings = { pitch: 1.0, volume: 1.0 }) {
  const fundamental = 880 * trackSettings.pitch;
  const duration = 2.0;
  
  const partials = [
    { freq: fundamental * 1.0, gain: 0.4 },
    { freq: fundamental * 2.0, gain: 0.2 },
    { freq: fundamental * 3.0, gain: 0.1 },
    { freq: fundamental * 4.193, gain: 0.05 },
    { freq: fundamental * 5.404, gain: 0.03 }
  ];
  
  partials.forEach(partial => {
    const osc = this.audioContext.createOscillator();
    osc.type = 'sine';
    osc.frequency.value = partial.freq;
    
    const gain = this.audioContext.createGain();
    gain.gain.setValueAtTime(partial.gain * trackSettings.volume, time);
    gain.gain.exponentialRampToValueAtTime(0.001, time + duration);
    
    osc.connect(gain);
    // ✅ 正しい接続先
    gain.connect(this.effectChain.pitch);
    
    osc.start(time);
    osc.stop(time + duration);
  });
}

// Harp ハープ（爽やかな弦楽器）
playHarp(time, trackSettings = { pitch: 1.0, volume: 1.0 }) {
  const fundamental = 523 * trackSettings.pitch;
  const duration = 1.5;
  
  const osc1 = this.audioContext.createOscillator();
  const osc2 = this.audioContext.createOscillator();
  
  osc1.type = 'triangle';
  osc2.type = 'sine';
  
  osc1.frequency.value = fundamental;
  osc2.frequency.value = fundamental * 2;
  
  osc1.frequency.exponentialRampToValueAtTime(fundamental * 0.998, time + 0.1);
  
  const gain1 = this.audioContext.createGain();
  const gain2 = this.audioContext.createGain();
  
  gain1.gain.setValueAtTime(0, time);
  gain1.gain.linearRampToValueAtTime(0.3 * trackSettings.volume, time + 0.01);
  gain1.gain.exponentialRampToValueAtTime(0.001, time + duration);
  
  gain2.gain.setValueAtTime(0, time);
  gain2.gain.linearRampToValueAtTime(0.15 * trackSettings.volume, time + 0.01);
  gain2.gain.exponentialRampToValueAtTime(0.001, time + duration);
  
  osc1.connect(gain1);
  osc2.connect(gain2);
  // ✅ 正しい接続先
  gain1.connect(this.effectChain.pitch);
  gain2.connect(this.effectChain.pitch);
  
  osc1.start(time);
  osc2.start(time);
  osc1.stop(time + duration);
  osc2.stop(time + duration);
}

// Flute フルート（柔らかい笛）
playFlute(time, trackSettings = { pitch: 1.0, volume: 1.0 }) {
  const fundamental = 1047 * trackSettings.pitch;
  const duration = 0.5;
  
  const osc = this.audioContext.createOscillator();
  osc.type = 'sine';
  osc.frequency.value = fundamental;
  
  const osc2 = this.audioContext.createOscillator();
  osc2.type = 'sine';
  osc2.frequency.value = fundamental * 2;
  
  // ブレス音
  const noiseBuffer = this.audioContext.createBuffer(1, this.audioContext.sampleRate * 0.05, this.audioContext.sampleRate);
  const output = noiseBuffer.getChannelData(0);
  for (let i = 0; i < noiseBuffer.length; i++) {
    output[i] = (Math.random() * 2 - 1) * 0.1;
  }
  const noise = this.audioContext.createBufferSource();
  noise.buffer = noiseBuffer;
  
  const noiseGain = this.audioContext.createGain();
  noiseGain.gain.setValueAtTime(0.05 * trackSettings.volume, time);
  noiseGain.gain.exponentialRampToValueAtTime(0.001, time + 0.05);
  
  const gain = this.audioContext.createGain();
  const gain2 = this.audioContext.createGain();
  
  gain.gain.setValueAtTime(0, time);
  gain.gain.linearRampToValueAtTime(0.3 * trackSettings.volume, time + 0.05);
  gain.gain.setValueAtTime(0.3 * trackSettings.volume, time + duration - 0.1);
  gain.gain.linearRampToValueAtTime(0, time + duration);
  
  gain2.gain.setValueAtTime(0, time);
  gain2.gain.linearRampToValueAtTime(0.1 * trackSettings.volume, time + 0.05);
  gain2.gain.setValueAtTime(0.1 * trackSettings.volume, time + duration - 0.1);
  gain2.gain.linearRampToValueAtTime(0, time + duration);
  
  // ビブラート
  const vibrato = this.audioContext.createOscillator();
  vibrato.frequency.value = 5;
  const vibratoGain = this.audioContext.createGain();
  vibratoGain.gain.value = 3;
  
  vibrato.connect(vibratoGain);
  vibratoGain.connect(osc.frequency);
  
  osc.connect(gain);
  osc2.connect(gain2);
  noise.connect(noiseGain);
  // ✅ 正しい接続先
  gain.connect(this.effectChain.pitch);
  gain2.connect(this.effectChain.pitch);
  noiseGain.connect(this.effectChain.pitch);
  
  vibrato.start(time);
  osc.start(time);
  osc2.start(time);
  noise.start(time);
  vibrato.stop(time + duration);
  osc.stop(time + duration);
  osc2.stop(time + duration);
}

// ==========================================
// 怖い音源グループ
// ==========================================

// DarkPad ダークパッド（不気味な持続音）
playDarkPad(time, trackSettings = { pitch: 1.0, volume: 1.0 }) {
  const fundamental = 110 * trackSettings.pitch;
  const duration = 1.0;
  
  const frequencies = [
    fundamental,
    fundamental * 1.5,
    fundamental * 1.414,
    fundamental * 0.5
  ];
  
  frequencies.forEach((freq) => {
    const osc = this.audioContext.createOscillator();
    osc.type = 'sawtooth';
    osc.frequency.value = freq;
    osc.detune.value = (Math.random() - 0.5) * 10;
    
    const gain = this.audioContext.createGain();
    const gainValue = (0.15 / frequencies.length) * trackSettings.volume;
    
    gain.gain.setValueAtTime(0, time);
    gain.gain.linearRampToValueAtTime(gainValue, time + 0.3);
    gain.gain.setValueAtTime(gainValue, time + duration - 0.2);
    gain.gain.linearRampToValueAtTime(0, time + duration);
    
    const lowpass = this.audioContext.createBiquadFilter();
    lowpass.type = 'lowpass';
    lowpass.frequency.value = 500;
    lowpass.Q.value = 5;
    
    osc.connect(lowpass);
    lowpass.connect(gain);
    // ✅ 正しい接続先
    gain.connect(this.effectChain.pitch);
    
    osc.start(time);
    osc.stop(time + duration);
  });
}

// Scream スクリーム（恐怖の叫び声風）
playScream(time, trackSettings = { pitch: 1.0, volume: 1.0 }) {
  const duration = 0.3;
  
  const bufferSize = this.audioContext.sampleRate * duration;
  const buffer = this.audioContext.createBuffer(1, bufferSize, this.audioContext.sampleRate);
  const output = buffer.getChannelData(0);
  
  for (let i = 0; i < bufferSize; i++) {
    output[i] = Math.random() * 2 - 1;
  }
  
  const noise = this.audioContext.createBufferSource();
  noise.buffer = buffer;
  noise.playbackRate.value = trackSettings.pitch;
  
  const bandpass1 = this.audioContext.createBiquadFilter();
  bandpass1.type = 'bandpass';
  bandpass1.frequency.value = 1500;
  bandpass1.Q.value = 3;
  
  const bandpass2 = this.audioContext.createBiquadFilter();
  bandpass2.type = 'bandpass';
  bandpass2.frequency.value = 3000;
  bandpass2.Q.value = 2;
  
  bandpass1.frequency.setValueAtTime(2000, time);
  bandpass1.frequency.exponentialRampToValueAtTime(1200, time + duration);
  
  const gain = this.audioContext.createGain();
  gain.gain.setValueAtTime(0.6 * trackSettings.volume, time);
  gain.gain.exponentialRampToValueAtTime(0.01, time + duration);
  
  noise.connect(bandpass1);
  bandpass1.connect(bandpass2);
  bandpass2.connect(gain);
  // ✅ 正しい接続先
  gain.connect(this.effectChain.pitch);
  
  noise.start(time);
  noise.stop(time + duration);
}

// Drone ドローン（持続する低音の不安感）
playDrone(time, trackSettings = { pitch: 1.0, volume: 1.0 }) {
  const fundamental = 55 * trackSettings.pitch;
  const duration = 2.0;
  
  const osc1 = this.audioContext.createOscillator();
  const osc2 = this.audioContext.createOscillator();
  
  osc1.type = 'sawtooth';
  osc2.type = 'sawtooth';
  
  osc1.frequency.value = fundamental;
  osc2.frequency.value = fundamental * 1.005;
  
  const gain = this.audioContext.createGain();
  gain.gain.setValueAtTime(0, time);
  gain.gain.linearRampToValueAtTime(0.3 * trackSettings.volume, time + 0.5);
  gain.gain.setValueAtTime(0.3 * trackSettings.volume, time + duration - 0.5);
  gain.gain.linearRampToValueAtTime(0, time + duration);
  
  const lowpass = this.audioContext.createBiquadFilter();
  lowpass.type = 'lowpass';
  lowpass.frequency.value = 200;
  lowpass.Q.value = 1;
  
  const lfo = this.audioContext.createOscillator();
  lfo.frequency.value = 0.5;
  const lfoGain = this.audioContext.createGain();
  lfoGain.gain.value = 50;
  
  lfo.connect(lfoGain);
  lfoGain.connect(lowpass.frequency);
  
  osc1.connect(lowpass);
  osc2.connect(lowpass);
  lowpass.connect(gain);
  // ✅ 正しい接続先
  gain.connect(this.effectChain.pitch);
  
  lfo.start(time);
  osc1.start(time);
  osc2.start(time);
  lfo.stop(time + duration);
  osc1.stop(time + duration);
  osc2.stop(time + duration);
}

// 楽器演奏の振り分け
playInstrument(instrument, time, trackSettings = { pitch: 1.0, volume: 1.0 }) {
  switch (instrument) {
    case 'Kick':
      this.playKick(time, trackSettings);
      break;
    case 'Snare':
      this.playSnare(time, trackSettings);
      break;
    case 'HiHat':
      this.playHiHat(time, trackSettings);
      break;
    case 'Zap':
      this.playZap(time, trackSettings);
      break;
    case 'Cymbal':
      this.playCymbal(time, trackSettings);
      break;
    case 'Clap':
      this.playClap(time, trackSettings);
      break;
    case 'Tom':
      this.playTom(time, trackSettings);
      break;
    case 'Whistle':
      this.playWhistle(time, trackSettings);
      break;
    case 'Bass':
      this.playBass(time, trackSettings);
      break;
    case 'Rimshot':
      this.playRimshot(time, trackSettings);
      break;
    case 'Cowbell':
      this.playCowbell(time, trackSettings);
      break;
    case 'Shinobue':
      this.playShinobue(time, trackSettings);
      break;
    case 'Glitch':
      this.playGlitch(time, trackSettings);
      break;
    case 'WobbleBass':
      this.playWobbleBass(time, trackSettings);
      break;
    case 'EGuitar':
      this.playEGuitar(time, trackSettings);
      break;
        case 'Bell':
      this.playBell(time, trackSettings);
      break;
    case 'Harp':
      this.playHarp(time, trackSettings);
      break;
    case 'Flute':
      this.playFlute(time, trackSettings);
      break;
    case 'DarkPad':
      this.playDarkPad(time, trackSettings);
      break;
    case 'Scream':
      this.playScream(time, trackSettings);
      break;
    case 'Drone':
      this.playDrone(time, trackSettings);
      break;
  }
}
}