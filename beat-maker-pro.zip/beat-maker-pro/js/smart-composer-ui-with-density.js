// ==========================================
// スマート作曲UI（ワイドレイアウト版）
// ==========================================

class SmartComposerUI {
  constructor(smartComposer) {
    this.composer = smartComposer;
  }
  
  createUI() {
    const controls = document.getElementById('controls');
    if (!controls) return;

    // ★スタイル定義（横並びレイアウト用）
    this.injectStyles();
    
    const section = document.createElement('div');
    section.className = 'smart-composer-section';
    
    // HTML構造を左右2カラムに変更
    section.innerHTML = `
      <div class="smart-header">
        <h3 class="smart-composer-title">🎼 スマート作曲システム</h3>
        <p class="smart-composer-description">
          設定を選んで「曲を作る」を押すと、AIが自動で作曲・保存します
        </p>
      </div>
      
      <div class="smart-body-row">
        <div class="smart-col-left">
        
          <div class="param-group">
            <h4 class="param-section-title">🎚️ 音の密度</h4>
            <div class="density-buttons">
              <button class="density-btn" data-density="sparse" title="音数：少なめ (40%)">
                <span class="density-icon">◦◦</span>
                <span class="density-label">少なめ</span>
              </button>
              <button class="density-btn active" data-density="normal" title="音数：普通 (100%)">
                <span class="density-icon">●●</span>
                <span class="density-label">普通</span>
              </button>
              <button class="density-btn" data-density="dense" title="音数：多め (180%)">
                <span class="density-icon">██</span>
                <span class="density-label">多め</span>
              </button>
            </div>
          </div>
          
          <div class="param-group">
            <h4 class="param-section-title">💭 感情パラメータ</h4>
            <div class="emotion-grid">
            
              <div class="emotion-cell">
                <label class="emotion-label">
                  <span class="param-icon">💕</span> やさしさ
                  <span class="val" id="composer-gentleness-value">50</span>
                </label>
                <input type="range" id="composer-gentleness" class="mini-slider" min="0" max="100" value="50">
              </div>
              
              <div class="emotion-cell">
                <label class="emotion-label">
                  <span class="param-icon">🌑</span> 暗さ
                  <span class="val" id="composer-darkness-value">50</span>
                </label>
                <input type="range" id="composer-darkness" class="mini-slider" min="0" max="100" value="50">
              </div>
              
              <div class="emotion-cell">
                <label class="emotion-label">
                  <span class="param-icon">🌸</span> はかなさ
                  <span class="val" id="composer-ephemerality-value">50</span>
                </label>
                <input type="range" id="composer-ephemerality" class="mini-slider" min="0" max="100" value="50">
              </div>
            </div>
          </div>

          <div class="param-group">
             <h4 class="param-section-title">⚡ プリセット</h4>
             <div class="preset-row">
               <button class="preset-btn" data-preset="gentle">💕やさしい</button>
               <button class="preset-btn" data-preset="dark">🌑暗い</button>
               <button class="preset-btn" data-preset="ephemeral">🌸はかない</button>
               <button class="preset-btn" data-preset="horror">👻ホラー</button>
             </div>
          </div>
        </div>

        <div class="smart-col-right">
          
          <div class="param-group">
            <h4 class="param-section-title">🎸 ジャンル選択</h4>
            <div class="genre-grid">
              <button class="genre-btn active" data-genre="pop">
                <span class="emoji">🎵</span> Pop
              </button>
              <button class="genre-btn" data-genre="rock">
                <span class="emoji">🎸</span> Rock
              </button>
              <button class="genre-btn" data-genre="bossanova">
                <span class="emoji">🌴</span> Bossa
              </button>
              <button class="genre-btn" data-genre="jazz">
                <span class="emoji">🎷</span> Jazz
              </button>
              <button class="genre-btn" data-genre="electronic">
                <span class="emoji">⚡</span> Electro
              </button>
              <button class="genre-btn" data-genre="ambient">
                <span class="emoji">🌊</span> Ambient
              </button>
              <button class="genre-btn horror-btn" data-genre="horror">
                <span class="emoji">👻</span> Horror
              </button>
            </div>
          </div>
          
          <div class="action-area">
            <button id="smart-compose-btn" class="smart-compose-button">
              <span class="btn-icon">🎼</span>
              <div class="btn-text">
                <span class="main-text">作曲＆保存</span>
                <span class="sub-text">Generate & Download JSON</span>
              </div>
            </button>
          </div>
          
        </div>
      </div>
    `;
    
    // 既存の要素の前に挿入（または追加）
    const firstChild = controls.firstChild;
    if (firstChild) {
      controls.insertBefore(section, firstChild);
    } else {
      controls.appendChild(section);
    }
    
    this.setupEventListeners();
  }

  // ★ CSSを動的に追加するメソッド
  injectStyles() {
    const styleId = 'smart-composer-styles';
    if (document.getElementById(styleId)) return;

    const css = `
      .smart-composer-section {
        background: #2a2a2a;
        border: 1px solid #444;
        border-radius: 12px;
        padding: 15px;
        margin-bottom: 20px;
        color: #eee;
        font-family: sans-serif;
      }
      .smart-header { margin-bottom: 15px; border-bottom: 1px solid #444; padding-bottom: 10px; }
      .smart-composer-title { margin: 0; font-size: 1.2rem; color: #fff; }
      .smart-composer-description { margin: 5px 0 0; font-size: 0.85rem; color: #aaa; }
      
      /* レイアウトグリッド */
      .smart-body-row {
        display: flex;
        gap: 20px;
        flex-wrap: wrap;
      }
      .smart-col-left { flex: 1; min-width: 280px; }
      .smart-col-right { flex: 0.8; min-width: 240px; display: flex; flex-direction: column; }
      
      .param-group { margin-bottom: 15px; }
      .param-section-title {
        margin: 0 0 8px 0;
        font-size: 0.85rem;
        color: #888;
        text-transform: uppercase;
        letter-spacing: 1px;
      }

      /* 密度ボタン */
      .density-buttons { display: flex; gap: 5px; background: #222; padding: 3px; border-radius: 6px; }
      .density-btn {
        flex: 1; border: none; background: transparent; color: #888;
        padding: 6px; font-size: 0.8rem; cursor: pointer; border-radius: 4px;
        display: flex; align-items: center; justify-content: center; gap: 5px;
        transition: all 0.2s;
      }
      .density-btn:hover { background: #333; color: #fff; }
      .density-btn.active { background: #4ECDC4; color: #000; font-weight: bold; }
      
      /* 感情グリッド */
      .emotion-grid {
        display: grid;
        grid-template-columns: repeat(3, 1fr); /* 3列 */
        gap: 10px;
      }
      .emotion-cell {
        background: #222; padding: 8px; border-radius: 6px; text-align: center;
      }
      .emotion-label { display: block; font-size: 0.75rem; margin-bottom: 5px; color: #ccc; }
      .emotion-label .val { float: right; color: #4ECDC4; }
      .mini-slider { width: 100%; height: 4px; accent-color: #4ECDC4; cursor: pointer; }
      
      /* ジャンルグリッド */
      .genre-grid {
        display: grid;
        grid-template-columns: repeat(3, 1fr); /* 3列 */
        gap: 8px;
      }
      .genre-btn {
        background: #333; border: 1px solid #444; color: #ccc;
        padding: 8px 4px; border-radius: 6px; cursor: pointer;
        display: flex; flex-direction: column; align-items: center; gap: 4px;
        font-size: 0.75rem; transition: all 0.2s;
      }
      .genre-btn .emoji { font-size: 1.2rem; }
      .genre-btn:hover { background: #444; border-color: #666; }
      .genre-btn.active { background: #FFE66D; color: #000; border-color: #FFE66D; font-weight: bold; }
      
      /* ホラーボタン特別色 */
      .horror-btn.active { background: #800080 !important; color: #fff !important; border-color: #a000a0 !important; }

      /* プリセット */
      .preset-row { display: flex; gap: 5px; flex-wrap: wrap; }
      .preset-btn {
        flex: 1; font-size: 0.75rem; padding: 5px;
        background: #222; border: 1px solid #444; color: #aaa;
        border-radius: 4px; cursor: pointer;
      }
      .preset-btn:hover { background: #333; color: #fff; }

      /* 作曲ボタン */
      .action-area { margin-top: auto; }
      .smart-compose-button {
        width: 100%;
        background: linear-gradient(135deg, #4ECDC4, #556270);
        border: none; color: white;
        padding: 12px; border-radius: 8px;
        cursor: pointer; display: flex; align-items: center; justify-content: center; gap: 10px;
        transition: transform 0.1s;
      }
      .smart-compose-button:hover { transform: scale(1.02); filter: brightness(1.1); }
      .smart-compose-button:active { transform: scale(0.98); }
      .smart-compose-button .btn-icon { font-size: 1.5rem; }
      .smart-compose-button .btn-text { text-align: left; line-height: 1.2; }
      .smart-compose-button .main-text { display: block; font-weight: bold; font-size: 1rem; }
      .smart-compose-button .sub-text { display: block; font-size: 0.7rem; opacity: 0.8; }
    `;

    const style = document.createElement('style');
    style.id = styleId;
    style.textContent = css;
    document.head.appendChild(style);
  }
  
  setupEventListeners() {
    // 密度ボタン
    document.querySelectorAll('.density-btn').forEach(btn => {
      btn.addEventListener('click', (e) => {
        const density = e.currentTarget.dataset.density;
        this.selectDensity(density);
      });
    });
    
    // 感情パラメータ
    document.getElementById('composer-gentleness')?.addEventListener('input', (e) => {
      this.updateEmotion('gentleness', e.target.value);
    });
    document.getElementById('composer-darkness')?.addEventListener('input', (e) => {
      this.updateEmotion('darkness', e.target.value);
    });
    document.getElementById('composer-ephemerality')?.addEventListener('input', (e) => {
      this.updateEmotion('ephemerality', e.target.value);
    });
    
    // ジャンルボタン
    document.querySelectorAll('.genre-btn').forEach(btn => {
      btn.addEventListener('click', (e) => {
        const genre = e.currentTarget.dataset.genre;
        this.selectGenre(genre);
      });
    });
    
    // 作曲ボタン
    document.getElementById('smart-compose-btn')?.addEventListener('click', () => {
      this.composer.compose();
    });
    
    // プリセットボタン
    document.querySelectorAll('.preset-btn').forEach(btn => {
      btn.addEventListener('click', (e) => {
        const preset = e.currentTarget.dataset.preset;
        this.applyPreset(preset);
      });
    });
  }
  
  // 値更新ヘルパー
  updateEmotion(type, value) {
    const intVal = parseInt(value);
    this.composer[type] = intVal;
    document.getElementById(`composer-${type}-value`).textContent = intVal;
  }
  
  selectDensity(density) {
    this.composer.setDensity(density);
    document.querySelectorAll('.density-btn').forEach(btn => {
      if (btn.dataset.density === density) {
        btn.classList.add('active');
      } else {
        btn.classList.remove('active');
      }
    });
  }
  
  selectGenre(genre) {
    this.composer.setGenre(genre);
    document.querySelectorAll('.genre-btn').forEach(btn => {
      if (btn.dataset.genre === genre) {
        btn.classList.add('active');
      } else {
        btn.classList.remove('active');
      }
    });
  }
  
  applyPreset(preset) {
    const presets = {
      gentle: { gentleness: 90, darkness: 20, ephemerality: 40 },
      dark: { gentleness: 30, darkness: 90, ephemerality: 50 },
      ephemeral: { gentleness: 70, darkness: 40, ephemerality: 90 },
      horror: { gentleness: 10, darkness: 100, ephemerality: 80 } // ホラー用プリセット
    };
    
    const values = presets[preset];
    if (!values) return;

    // スライダー更新
    this.setEmotionSliders(values.gentleness, values.darkness, values.ephemerality);
    // 内部値更新
    this.composer.setEmotion(values.gentleness, values.darkness, values.ephemerality);
    
    // ホラープリセットならジャンルも変える
    if (preset === 'horror') {
        this.selectGenre('horror');
    }
    
    this.composer.compose();
  }
  
  setEmotionSliders(gentleness, darkness, ephemerality) {
    const update = (id, val) => {
        const el = document.getElementById(id);
        const disp = document.getElementById(id + '-value');
        if(el) el.value = val;
        if(disp) disp.textContent = val;
    };
    update('composer-gentleness', gentleness);
    update('composer-darkness', darkness);
    update('composer-ephemerality', ephemerality);
  }
}