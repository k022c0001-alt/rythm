// ==========================================
// スマート作曲システム（感情×ジャンル対応）
// ==========================================

class SmartComposer {
  constructor(app) {
    this.app = app;
    this.uiManager = app.uiManager;
    this.sequencer = app.sequencer;
    this.audioEngine = app.audioEngine;
    
    // 感情パラメータ
    this.gentleness = 50;    // やさしさ (0-100)
    this.darkness = 50;      // 暗さ (0-100)
    this.ephemerality = 50;  // はかなさ (0-100)
    
    // 現在のジャンル
    this.currentGenre = 'pop';
  }
  
  // ==========================================
  // ジャンル別のルール定義
  // ==========================================
  
  getGenreRules(genre) {
    const rules = {
      pop: {
        name: 'ポップ',
        emoji: '🎵',
        bpmRange: [110, 140],
        instruments: {
          rhythm: ['Kick', 'Snare', 'HiHat'],
          melody: ['Bell', 'Harp', 'Whistle'],
          bass: ['Bass']
        },
        patterns: {
          kick: [1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0],      // 4つ打ち
          snare: [0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0],     // 裏拍
          hihat: [1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0]      // 8分音符
        },
        density: 0.4,
        swing: [0, 10]
      },
      
      rock: {
        name: 'ロック',
        emoji: '🎸',
        bpmRange: [120, 160],
        instruments: {
          rhythm: ['Kick', 'Snare', 'HiHat', 'Cymbal', 'Tom'],
          melody: ['EGuitar', 'Zap'],
          bass: ['Bass', 'WobbleBass']
        },
        patterns: {
          kick: [1, 0, 0, 0, 1, 0, 1, 0, 1, 0, 0, 0, 1, 0, 1, 0],      // ロックビート
          snare: [0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0],
          hihat: [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1]      // 16分音符
        },
        density: 0.5,
        swing: [0, 5]
      },
      
      bossanova: {
        name: 'ボサノバ',
        emoji: '🌴',
        bpmRange: [100, 130],
        instruments: {
          rhythm: ['Rimshot', 'Clap', 'HiHat'],
          melody: ['Flute', 'Harp', 'Bell'],
          bass: ['Bass']
        },
        patterns: {
          kick: [1, 0, 0, 1, 0, 0, 1, 0, 1, 0, 0, 1, 0, 0, 1, 0],      // ボサノバリズム
          snare: [0, 0, 1, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 1, 0, 0],
          hihat: [1, 0, 0, 1, 0, 0, 1, 0, 1, 0, 0, 1, 0, 0, 1, 0]      // 3-2クラーベ風
        },
        density: 0.3,
        swing: [20, 40]
      },
      
      jazz: {
        name: 'ジャズ',
        emoji: '🎷',
        bpmRange: [90, 140],
        instruments: {
          rhythm: ['Rimshot', 'HiHat', 'Cymbal'],
          melody: ['Shinobue', 'Whistle', 'Harp'],
          bass: ['Bass']
        },
        patterns: {
          kick: [1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0],      // スウィング
          snare: [0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 1, 0, 0, 0, 0, 1],
          hihat: [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1]      // シンバルレガート
        },
        density: 0.35,
        swing: [30, 50]
      },
      
      ambient: {
        name: 'アンビエント',
        emoji: '🌊',
        bpmRange: [60, 90],
        instruments: {
          rhythm: ['Cymbal', 'Cowbell'],
          melody: ['DarkPad', 'Drone', 'Bell', 'Harp'],
          bass: ['Drone']
        },
        patterns: {
          kick: [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],      // 希薄
          snare: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
          hihat: [0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0]
        },
        density: 0.15,
        swing: [0, 20]
      },
      
      electronic: {
        name: 'エレクトロニック',
        emoji: '⚡',
        bpmRange: [120, 140],
        instruments: {
          rhythm: ['Kick', 'Snare', 'HiHat', 'Clap', 'Glitch'],
          melody: ['Zap', 'WobbleBass', 'Glitch'],
          bass: ['WobbleBass']
        },
        patterns: {
          kick: [1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0],      // 4つ打ち
          snare: [0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0],
          hihat: [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1]      // 細かく
        },
        density: 0.45,
        swing: [0, 15]
      }
    };
    
    return rules[genre] || rules.pop;
  }
  
  // ==========================================
  // スマート作曲メイン処理
  // ==========================================
  
  compose() {
    const genre = this.getGenreRules(this.currentGenre);
    
    // グリッドをクリア
    this.clearAllCells();
    
    // 1. リズムセクション作成
    this.createRhythmSection(genre);
    
    // 2. ベースライン作成
    this.createBassline(genre);
    
    // 3. メロディ作成
    this.createMelody(genre);
    
    // 4. BPMとSwing設定
    this.setBPMAndSwing(genre);
    
    // 5. エフェクト設定
    this.applyGenreEffect(genre);
    
    // ステータス表示
    const emotion = this.getEmotionDescription();
    this.uiManager.showStatus(
      `${genre.emoji} ${genre.name}で${emotion}な曲を作成しました！`,
      'success'
    );
    this.autoDownloadJSON(genre.name);
  }
  
  // グリッドをクリア
  clearAllCells() {
    for (let row = 0; row < CONFIG.ROWS; row++) {
      for (let col = 0; col < CONFIG.COLS; col++) {
        const grid = this.uiManager.pages[this.uiManager.currentPageIndex].grid;
        if (grid[row][col]) {
          this.uiManager.toggleCell(row, col);
        }
      }
    }
  }
  
  // ==========================================
  // リズムセクション作成
  // ==========================================
  
  createRhythmSection(genre) {
    const rhythmInstruments = genre.instruments.rhythm;
    
    rhythmInstruments.forEach(instrumentName => {
      const row = this.findInstrumentRow(instrumentName);
      if (row === -1) return;
      
      // パターンを取得（Kick, Snare, HiHatのみ専用パターン使用）
      let pattern;
      if (instrumentName === 'Kick' && genre.patterns.kick) {
        pattern = genre.patterns.kick;
      } else if (instrumentName === 'Snare' && genre.patterns.snare) {
        pattern = genre.patterns.snare;
      } else if (instrumentName === 'HiHat' && genre.patterns.hihat) {
        pattern = genre.patterns.hihat;
      } else {
        pattern = this.generateRhythmPattern(genre.density);
      }
      
      // パターンを配置（感情パラメータで調整）
      pattern.forEach((shouldPlace, col) => {
        // はかなさが高いと音を減らす
        const ephemeralityFactor = 1 - (this.ephemerality / 200);
        
        if (shouldPlace && Math.random() < ephemeralityFactor) {
          this.uiManager.toggleCell(row, col, 0);
        }
      });
    });
  }
  
  // リズムパターン生成
  generateRhythmPattern(baseDensity) {
    const pattern = [];
    // やさしさが高いと密度を下げる
    const gentlenessFactor = 1 - (this.gentleness / 200);
    const adjustedDensity = baseDensity * gentlenessFactor;
    
    for (let i = 0; i < CONFIG.COLS; i++) {
      pattern.push(Math.random() < adjustedDensity ? 1 : 0);
    }
    
    return pattern;
  }
  
  // ==========================================
  // ベースライン作成
  // ==========================================
  
  createBassline(genre) {
    const bassInstruments = genre.instruments.bass;
    const bassName = bassInstruments[Math.floor(Math.random() * bassInstruments.length)];
    const row = this.findInstrumentRow(bassName);
    
    if (row === -1) return;
    
    // 暗さに応じてベースの密度を変更
    const darknessFactor = 0.5 + (this.darkness / 200);
    const bassDensity = 0.25 * darknessFactor;
    
    // ベース音程の選択（暗いほど低音）
    const noteRange = this.darkness > 50 ? [0, 2] : [0, 4];
    
    for (let col = 0; col < CONFIG.COLS; col += 2) {  // 2ステップごと
      if (Math.random() < bassDensity) {
        const noteIndex = noteRange[0] + Math.floor(Math.random() * (noteRange[1] - noteRange[0] + 1));
        this.uiManager.toggleCell(row, col, noteIndex);
      }
    }
  }
  
  // ==========================================
  // メロディ作成
  // ==========================================
  
  createMelody(genre) {
    const melodyInstruments = genre.instruments.melody;
    
    // やさしさが高いほど多くの楽器を使用
    const numInstruments = Math.floor(1 + (this.gentleness / 50));
    
    for (let i = 0; i < Math.min(numInstruments, melodyInstruments.length); i++) {
      const instrumentName = melodyInstruments[i];
      const row = this.findInstrumentRow(instrumentName);
      
      if (row === -1) continue;
      
      this.createMelodyLine(row, genre);
    }
  }
  
  createMelodyLine(row, genre) {
    const instrument = CONFIG.INSTRUMENTS[row];
    
    // メロディの密度（はかなさが高いほど薄く）
    const baseDensity = genre.density * 0.5;
    const ephemeralityFactor = 1 - (this.ephemerality / 150);
    const melodyDensity = baseDensity * ephemeralityFactor;
    
    // 音程範囲の決定
    let noteRange;
    if (this.darkness > 60) {
      noteRange = [0, 4];  // 暗い: 低〜中音域
    } else if (this.gentleness > 60) {
      noteRange = [4, 9];  // やさしい: 中音域
    } else {
      noteRange = [7, 12]; // 明るい: 高音域
    }
    
    // メロディパターンを生成
    if (instrument.isMelodic) {
      // 音階に沿ったメロディ
      const scale = this.getScale();
      let lastNote = scale[Math.floor(scale.length / 2)];
      
      for (let col = 0; col < CONFIG.COLS; col++) {
        if (Math.random() < melodyDensity) {
          // 前の音から近い音を選ぶ（なめらかなメロディ）
          const step = Math.floor(Math.random() * 5) - 2;  // -2 to +2
          const noteIndex = Math.max(noteRange[0], Math.min(noteRange[1], lastNote + step));
          
          this.uiManager.toggleCell(row, col, noteIndex);
          lastNote = noteIndex;
        }
      }
    }
  }
  
  // 音階を取得（感情に応じて）
  getScale() {
    if (this.darkness > 60) {
      // 暗い: マイナースケール的
      return [0, 2, 3, 5, 7, 8, 10];
    } else if (this.gentleness > 60) {
      // やさしい: ペンタトニック
      return [0, 2, 4, 7, 9];
    } else {
      // 明るい: メジャースケール
      return [0, 2, 4, 5, 7, 9, 11];
    }
  }
  
  // ==========================================
  // BPMとSwing設定
  // ==========================================
  
  setBPMAndSwing(genre) {
    // BPM: ジャンル範囲内でランダム
    let bpm = genre.bpmRange[0] + Math.random() * (genre.bpmRange[1] - genre.bpmRange[0]);
    
    // はかなさが高いと遅く
    bpm -= (this.ephemerality / 100) * 20;
    
    // 暗さが高いと遅く
    bpm -= (this.darkness / 100) * 15;
    
    bpm = Math.round(Math.max(60, Math.min(200, bpm)));
    
    // Swing: ジャンル範囲内でランダム
    let swing = genre.swing[0] + Math.random() * (genre.swing[1] - genre.swing[0]);
    
    // やさしさが高いとSwing増加
    swing += (this.gentleness / 100) * 10;
    
    swing = Math.round(Math.max(0, Math.min(50, swing)));
    
    // 適用
    this.uiManager.setParameters({ bpm, swing });
    this.sequencer.setBPM(bpm);
    this.sequencer.setSwing(swing);
  }
  
  // ==========================================
  // ジャンル別エフェクト
  // ==========================================
  
  applyGenreEffect(genre) {
    let effect;
    
    switch (this.currentGenre) {
      case 'pop':
        effect = { decay: 90, delayTime: 150, delayFeedback: 20, delayMix: 25, pitch: 0 };
        break;
      case 'rock':
        effect = { decay: 85, delayTime: 100, delayFeedback: 15, delayMix: 20, pitch: 0 };
        break;
      case 'bossanova':
        effect = { decay: 92, delayTime: 200, delayFeedback: 25, delayMix: 30, pitch: 0 };
        break;
      case 'jazz':
        effect = { decay: 88, delayTime: 180, delayFeedback: 22, delayMix: 28, pitch: 0 };
        break;
      case 'ambient':
        effect = { decay: 95, delayTime: 500, delayFeedback: 45, delayMix: 50, pitch: 2 };
        break;
      case 'electronic':
        effect = { decay: 87, delayTime: 250, delayFeedback: 30, delayMix: 35, pitch: 0 };
        break;
      default:
        effect = { decay: 90, delayTime: 150, delayFeedback: 20, delayMix: 25, pitch: 0 };
    }
    
    // 感情に応じて微調整
    if (this.ephemerality > 70) {
      effect.delayMix += 15;
      effect.decay += 5;
    }
    
    if (this.darkness > 70) {
      effect.pitch -= 2;
    }
    
    if (this.gentleness > 70) {
      effect.delayFeedback += 10;
    }
    
    // 適用
    this.uiManager.setParameters(effect);
    this.audioEngine.setDecay(effect.decay / 100);
    this.audioEngine.setDelayTime(effect.delayTime / 1000);
    this.audioEngine.setDelayFeedback(effect.delayFeedback / 100);
    this.audioEngine.setDelayMix(effect.delayMix / 100);
  }
  
  // ==========================================
  // ユーティリティ
  // ==========================================
  
  findInstrumentRow(instrumentName) {
    return CONFIG.INSTRUMENTS.findIndex(inst => inst.name === instrumentName);
  }
  
  getEmotionDescription() {
    const parts = [];
    
    if (this.gentleness > 70) parts.push('やさしく');
    if (this.darkness > 70) parts.push('暗く');
    if (this.ephemerality > 70) parts.push('はかない');
    
    if (parts.length === 0) return 'バランスの取れた';
    return parts.join('');
  }
  
  // 感情パラメータを設定
  setEmotion(gentleness, darkness, ephemerality) {
    this.gentleness = Math.max(0, Math.min(100, gentleness));
    this.darkness = Math.max(0, Math.min(100, darkness));
    this.ephemerality = Math.max(0, Math.min(100, ephemerality));
  }
  
  // ジャンルを設定
  setGenre(genre) {
    this.currentGenre = genre;
  }
  autoDownloadJSON(genreName) {
    // 1. 保存するデータを収集 (UIManagerから最新データを取得)
    const exportData = {
      info: {
        version: "2.1",
        generatedBy: "SmartComposer",
        genre: genreName,
        date: new Date().toISOString(),
        emotion: {
          gentleness: this.gentleness,
          darkness: this.darkness,
          ephemerality: this.ephemerality
        }
      },
      // 楽譜データ（全ページ）
      pages: this.uiManager.getAllPageData(), 
      // BPM, Swing, エフェクト設定
      settings: this.uiManager.getParameters(), 
      // 各トラックの音量・ピッチ
      tracks: this.uiManager.getTrackSettings() 
    };

    // 2. JSON文字列に変換
    const jsonString = JSON.stringify(exportData, null, 2);

    // 3. ダウンロード用リンクを作成して自動クリック
    const blob = new Blob([jsonString], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    
    // ファイル名: "SmartCompose_ポップ_20231027..." のようにわかりやすく
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
    a.href = url;
    a.download = `SmartCompose_${genreName}_${timestamp}.json`;
    
    document.body.appendChild(a);
    a.click(); // ここでダウンロードが始まります
    
    // 4. お掃除
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    
    console.log("🎹 自動生成された曲をJSONとして保存しました");
  }
}