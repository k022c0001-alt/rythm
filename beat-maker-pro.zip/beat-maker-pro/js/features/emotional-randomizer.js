// ==========================================
// 感情的ランダマイザー（ランダム曲生成ボタン追加版）
// ==========================================

class EmotionalRandomizer {
  constructor(app) {
    this.app = app;
    this.uiManager = app.uiManager;
    this.sequencer = app.sequencer;
    
    // 感情パラメータ（0-100）
    this.brightness = 50;
    this.gentleness = 50;
    this.ephemerality = 50;
  }
  
  // UIを生成
  createUI() {
    const existingBtn = document.getElementById('randomize-btn');
    if (!existingBtn) return;
    
    const parentDiv = existingBtn.parentElement;
    existingBtn.remove();
    
    const container = document.createElement('div');
    container.className = 'emotional-randomizer';
    container.innerHTML = `
      <div class="emotion-controls">
        <h3 class="emotion-title">🎭 感情的ランダマイザー</h3>
        
        <!-- ★★★ 新規追加: ランダム曲生成ボタン ★★★ -->
        <div class="quick-random-section">
          <button id="quick-random-btn" class="quick-random-button">
            🎲 完全ランダムで曲を生成
          </button>
          <p class="quick-random-hint">
            感情パラメータもランダムに設定して、予想外の曲を作ります
          </p>
        </div>
        
        <div class="emotion-slider-group">
          <div class="emotion-slider-item">
            <label class="emotion-label">
              <span class="emotion-icon">☀️</span>
              明るさ
              <span class="emotion-value" id="brightness-value">50</span>
            </label>
            <input type="range" id="brightness-slider" 
                   class="emotion-slider" 
                   min="0" max="100" value="50" step="1">
            <div class="emotion-description">
              暗い ← → 明るい
            </div>
          </div>
          
          <div class="emotion-slider-item">
            <label class="emotion-label">
              <span class="emotion-icon">💕</span>
              やさしさ
              <span class="emotion-value" id="gentleness-value">50</span>
            </label>
            <input type="range" id="gentleness-slider" 
                   class="emotion-slider" 
                   min="0" max="100" value="50" step="1">
            <div class="emotion-description">
              激しい ← → やさしい
            </div>
          </div>
          
          <div class="emotion-slider-item">
            <label class="emotion-label">
              <span class="emotion-icon">🌸</span>
              はかなさ
              <span class="emotion-value" id="ephemerality-value">50</span>
            </label>
            <input type="range" id="ephemerality-slider" 
                   class="emotion-slider" 
                   min="0" max="100" value="50" step="1">
            <div class="emotion-description">
              しっかり ← → はかない
            </div>
          </div>
        </div>
        
        <div class="emotion-buttons">
          <button id="emotional-randomize-btn" class="emotional-randomize-button">
            🎲 感情で生成
          </button>
          <button id="preset-bright-btn" class="preset-button">☀️ 明るい</button>
          <button id="preset-gentle-btn" class="preset-button">💕 やさしい</button>
          <button id="preset-ephemeral-btn" class="preset-button">🌸 はかない</button>
          <button id="preset-dark-btn" class="preset-button">🌑 暗い</button>
        </div>
      </div>
    `;
    
    parentDiv.appendChild(container);
    this.setupEventListeners();
  }
  
  // イベントリスナー設定
  setupEventListeners() {
    // ★★★ 新規追加: 完全ランダム曲生成 ★★★
    document.getElementById('quick-random-btn').addEventListener('click', () => {
      this.generateCompletelyRandomSong();
    });
    
    // スライダー
    document.getElementById('brightness-slider').addEventListener('input', (e) => {
      this.brightness = parseInt(e.target.value);
      document.getElementById('brightness-value').textContent = this.brightness;
    });
    
    document.getElementById('gentleness-slider').addEventListener('input', (e) => {
      this.gentleness = parseInt(e.target.value);
      document.getElementById('gentleness-value').textContent = this.gentleness;
    });
    
    document.getElementById('ephemerality-slider').addEventListener('input', (e) => {
      this.ephemerality = parseInt(e.target.value);
      document.getElementById('ephemerality-value').textContent = this.ephemerality;
    });
    
    // 生成ボタン
    document.getElementById('emotional-randomize-btn').addEventListener('click', () => {
      this.generateEmotionalPattern();
    });
    
    // プリセットボタン
    document.getElementById('preset-bright-btn').addEventListener('click', () => {
      this.applyPreset('bright');
    });
    
    document.getElementById('preset-gentle-btn').addEventListener('click', () => {
      this.applyPreset('gentle');
    });
    
    document.getElementById('preset-ephemeral-btn').addEventListener('click', () => {
      this.applyPreset('ephemeral');
    });
    
    document.getElementById('preset-dark-btn').addEventListener('click', () => {
      this.applyPreset('dark');
    });
  }
  
  // ★★★ 新機能: 完全ランダム曲生成 ★★★
  generateCompletelyRandomSong() {
    // 感情パラメータもランダムに設定
    this.brightness = Math.floor(Math.random() * 100);
    this.gentleness = Math.floor(Math.random() * 100);
    this.ephemerality = Math.floor(Math.random() * 100);
    
    // スライダーを更新
    document.getElementById('brightness-slider').value = this.brightness;
    document.getElementById('gentleness-slider').value = this.gentleness;
    document.getElementById('ephemerality-slider').value = this.ephemerality;
    
    document.getElementById('brightness-value').textContent = this.brightness;
    document.getElementById('gentleness-value').textContent = this.gentleness;
    document.getElementById('ephemerality-value').textContent = this.ephemerality;
    
    // パターン生成
    this.generateEmotionalPattern();
    
    // 特別なステータス表示
    this.uiManager.showStatus('🎲 完全ランダムな曲を生成しました！', 'success');
  }
  
  // プリセット適用
  applyPreset(presetName) {
    const presets = {
      bright: { brightness: 90, gentleness: 60, ephemerality: 30 },
      gentle: { brightness: 70, gentleness: 90, ephemerality: 50 },
      ephemeral: { brightness: 60, gentleness: 70, ephemerality: 90 },
      dark: { brightness: 20, gentleness: 30, ephemerality: 60 }
    };
    
    const preset = presets[presetName];
    if (!preset) return;
    
    this.brightness = preset.brightness;
    this.gentleness = preset.gentleness;
    this.ephemerality = preset.ephemerality;
    
    document.getElementById('brightness-slider').value = this.brightness;
    document.getElementById('gentleness-slider').value = this.gentleness;
    document.getElementById('ephemerality-slider').value = this.ephemerality;
    
    document.getElementById('brightness-value').textContent = this.brightness;
    document.getElementById('gentleness-value').textContent = this.gentleness;
    document.getElementById('ephemerality-value').textContent = this.ephemerality;
    
    this.generateEmotionalPattern();
  }
  
  // 感情パラメータに基づいてパターン生成
  generateEmotionalPattern() {
    const instruments = this.selectInstrumentsByEmotion();
    const { bpm, swing } = this.calculateBPMAndSwing();
    
    // グリッドをクリア
    for (let row = 0; row < CONFIG.ROWS; row++) {
      for (let col = 0; col < CONFIG.COLS; col++) {
        const currentGrid = this.uiManager.pages[this.uiManager.currentPageIndex].grid;
        if (currentGrid[row][col]) {
          this.uiManager.toggleCell(row, col);
        }
      }
    }
    
    // 選択された楽器でパターンを生成
    instruments.forEach(instrumentInfo => {
      this.generatePatternForInstrument(instrumentInfo);
    });
    
    // BPMとSwingを設定
    this.uiManager.setParameters({ bpm, swing });
    this.sequencer.setBPM(bpm);
    this.sequencer.setSwing(swing);
    
    const emotionText = this.getEmotionDescription();
    this.uiManager.showStatus(`🎭 ${emotionText}なパターンを生成しました`, 'success');
  }
  
  // 感情に基づいて楽器を選択
  selectInstrumentsByEmotion() {
    const selected = [];
    
    // 明るさに基づく選択
    if (this.brightness > 60) {
      selected.push({ row: this.findInstrumentRow('Bell'), density: 0.2, noteRange: 'high' });
      selected.push({ row: this.findInstrumentRow('Harp'), density: 0.25, noteRange: 'mid' });
      selected.push({ row: this.findInstrumentRow('Cymbal'), density: 0.15, noteRange: null });
      selected.push({ row: this.findInstrumentRow('HiHat'), density: 0.3, noteRange: null });
    } else if (this.brightness < 40) {
      selected.push({ row: this.findInstrumentRow('DarkPad'), density: 0.3, noteRange: 'low' });
      selected.push({ row: this.findInstrumentRow('Drone'), density: 0.2, noteRange: 'low' });
      selected.push({ row: this.findInstrumentRow('Bass'), density: 0.25, noteRange: 'low' });
      selected.push({ row: this.findInstrumentRow('Kick'), density: 0.25, noteRange: null });
    } else {
      selected.push({ row: this.findInstrumentRow('Whistle'), density: 0.2, noteRange: 'mid' });
      selected.push({ row: this.findInstrumentRow('Snare'), density: 0.2, noteRange: null });
    }
    
    // やさしさに基づく選択
    if (this.gentleness > 60) {
      selected.push({ row: this.findInstrumentRow('Flute'), density: 0.25, noteRange: 'mid' });
      selected.push({ row: this.findInstrumentRow('Shinobue'), density: 0.2, noteRange: 'high' });
    } else if (this.gentleness < 40) {
      selected.push({ row: this.findInstrumentRow('Scream'), density: 0.15, noteRange: null });
      selected.push({ row: this.findInstrumentRow('Glitch'), density: 0.2, noteRange: null });
      selected.push({ row: this.findInstrumentRow('Snare'), density: 0.3, noteRange: null });
    }
    
    // はかなさに基づく選択
    if (this.ephemerality > 60) {
      selected.push({ row: this.findInstrumentRow('Bell'), density: 0.15, noteRange: 'high' });
      selected.push({ row: this.findInstrumentRow('Cymbal'), density: 0.1, noteRange: null });
    } else if (this.ephemerality < 40) {
      selected.push({ row: this.findInstrumentRow('Bass'), density: 0.35, noteRange: 'low' });
      selected.push({ row: this.findInstrumentRow('Kick'), density: 0.3, noteRange: null });
      selected.push({ row: this.findInstrumentRow('Tom'), density: 0.25, noteRange: null });
    }
    
    // 重複を除去
    const uniqueRows = new Map();
    selected.forEach(item => {
      if (item.row !== -1 && !uniqueRows.has(item.row)) {
        uniqueRows.set(item.row, item);
      }
    });
    
    return Array.from(uniqueRows.values());
  }
  
  // 楽器名から行番号を取得
  findInstrumentRow(instrumentName) {
    return CONFIG.INSTRUMENTS.findIndex(inst => inst.name === instrumentName);
  }
  
  // 特定の楽器にパターンを生成
  generatePatternForInstrument(instrumentInfo) {
    const { row, density, noteRange } = instrumentInfo;
    
    if (row === -1) return;
    
    const instrument = CONFIG.INSTRUMENTS[row];
    
    for (let col = 0; col < CONFIG.COLS; col++) {
      if (Math.random() < density) {
        if (instrument.isMelodic && noteRange) {
          const noteIndex = this.selectNoteByRange(noteRange);
          this.uiManager.toggleCell(row, col, noteIndex);
        } else {
          this.uiManager.toggleCell(row, col, 0);
        }
      }
    }
  }
  
  // 音域に基づいて音程を選択
  selectNoteByRange(range) {
    const notes = CONFIG.NOTES;
    
    if (range === 'low') {
      return Math.floor(Math.random() * 6);
    } else if (range === 'mid') {
      return 4 + Math.floor(Math.random() * 6);
    } else if (range === 'high') {
      return 7 + Math.floor(Math.random() * 6);
    }
    
    return 0;
  }
  
  // BPMとSwingを計算
  calculateBPMAndSwing() {
    let bpm = 120;
    bpm += (this.brightness - 50) * 0.6;
    bpm -= (this.ephemerality - 50) * 0.4;
    bpm = Math.max(60, Math.min(200, Math.round(bpm)));
    
    let swing = Math.round((this.gentleness - 50) * 0.5);
    swing = Math.max(0, Math.min(50, swing));
    
    return { bpm, swing };
  }
  
  // 感情の説明文を取得
  getEmotionDescription() {
    const parts = [];
    
    if (this.brightness > 70) parts.push('明るく');
    else if (this.brightness < 30) parts.push('暗く');
    
    if (this.gentleness > 70) parts.push('やさしく');
    else if (this.gentleness < 30) parts.push('激しく');
    
    if (this.ephemerality > 70) parts.push('はかない');
    else if (this.ephemerality < 30) parts.push('しっかりした');
    
    return parts.length > 0 ? parts.join('') : 'バランスの取れた';
  }
}