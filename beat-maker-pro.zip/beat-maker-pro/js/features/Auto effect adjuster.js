// ==========================================
// 自動エフェクト調整機能
// ==========================================

class AutoEffectAdjuster {
  constructor(app) {
    this.app = app;
    this.audioEngine = app.audioEngine;
    this.uiManager = app.uiManager;
    this.sequencer = app.sequencer;
  }
  
  // UIを生成
  createUI() {
    const controls = document.getElementById('controls');
    if (!controls) return;
    
    // エフェクトセクションを追加
    const effectSection = document.createElement('div');
    effectSection.className = 'auto-effect-section';
    effectSection.innerHTML = `
      <h3 class="auto-effect-title">✨ 自動エフェクト調整</h3>
      <div class="auto-effect-description">
        曲の雰囲気に合わせて、エフェクト（残響、ピッチ、ディレイ）を自動調整します
      </div>
      <div class="auto-effect-buttons">
        <button id="effect-natural-btn" class="auto-effect-btn">
          🌿 ナチュラル
          <span class="effect-hint">控えめな残響</span>
        </button>
        <button id="effect-spacious-btn" class="auto-effect-btn">
          🌌 広がり
          <span class="effect-hint">空間的な響き</span>
        </button>
        <button id="effect-dreamy-btn" class="auto-effect-btn">
          💫 夢幻的
          <span class="effect-hint">ディレイ強め</span>
        </button>
        <button id="effect-psychedelic-btn" class="auto-effect-btn">
          🌀 サイケデリック
          <span class="effect-hint">変化する音程</span>
        </button>
        <button id="effect-clear-btn" class="auto-effect-btn reset">
          🔄 クリア
          <span class="effect-hint">エフェクトなし</span>
        </button>
      </div>
    `;
    
    // BPMコントロールの後に挿入
    const firstControl = controls.querySelector('.control-group');
    if (firstControl) {
      controls.insertBefore(effectSection, firstControl);
    } else {
      controls.appendChild(effectSection);
    }
    
    this.setupEventListeners();
  }
  
  // イベントリスナー設定
  setupEventListeners() {
    document.getElementById('effect-natural-btn')?.addEventListener('click', () => {
      this.applyNaturalEffect();
    });
    
    document.getElementById('effect-spacious-btn')?.addEventListener('click', () => {
      this.applyspaciousEffect();
    });
    
    document.getElementById('effect-dreamy-btn')?.addEventListener('click', () => {
      this.applyDreamyEffect();
    });
    
    document.getElementById('effect-psychedelic-btn')?.addEventListener('click', () => {
      this.applyPsychedelicEffect();
    });
    
    document.getElementById('effect-clear-btn')?.addEventListener('click', () => {
      this.clearEffects();
    });
  }
  
  // ナチュラルエフェクト（控えめな残響）
  applyNaturalEffect() {
    const params = {
      decay: 85,           // 少し短め
      delayTime: 100,      // 軽いディレイ
      delayFeedback: 15,   // 控えめなフィードバック
      delayMix: 20,        // 控えめなミックス
      pitch: 0             // ピッチ変更なし
    };
    
    this.applyEffectParams(params);
    this.uiManager.showStatus('🌿 ナチュラルエフェクトを適用しました', 'success');
  }
  
  // 広がりエフェクト（空間的な響き）
  applyspaciousEffect() {
    const params = {
      decay: 95,           // 長めの余韻
      delayTime: 250,      // 中程度のディレイ
      delayFeedback: 30,   // 適度なフィードバック
      delayMix: 35,        // 適度なミックス
      pitch: 0             // ピッチ変更なし
    };
    
    this.applyEffectParams(params);
    this.uiManager.showStatus('🌌 広がりエフェクトを適用しました', 'success');
  }
  
  // 夢幻的エフェクト（ディレイ強め）
  applyDreamyEffect() {
    const params = {
      decay: 92,           // やや長めの余韻
      delayTime: 500,      // 長めのディレイ
      delayFeedback: 45,   // 強めのフィードバック
      delayMix: 50,        // バランス良いミックス
      pitch: 2             // わずかに高く
    };
    
    this.applyEffectParams(params);
    this.uiManager.showStatus('💫 夢幻的エフェクトを適用しました', 'success');
  }
  
  // サイケデリックエフェクト（変化する音程）
  applyPsychedelicEffect() {
    const params = {
      decay: 88,           // 中程度の余韻
      delayTime: 375,      // 不規則なディレイ
      delayFeedback: 55,   // かなり強めのフィードバック
      delayMix: 60,        // エフェクト強め
      pitch: -3            // 低めのピッチ
    };
    
    this.applyEffectParams(params);
    this.uiManager.showStatus('🌀 サイケデリックエフェクトを適用しました', 'success');
  }
  
  // エフェクトクリア
  clearEffects() {
    const params = {
      decay: 100,
      delayTime: 0,
      delayFeedback: 0,
      delayMix: 0,
      pitch: 0
    };
    
    this.applyEffectParams(params);
    this.uiManager.showStatus('🔄 エフェクトをクリアしました', 'success');
  }
  
  // エフェクトパラメータを適用
  applyEffectParams(params) {
    // UIの更新
    this.uiManager.setParameters(params);
    
    // オーディオエンジンに適用
    this.audioEngine.setDecay(params.decay / 100);
    this.audioEngine.setDelayTime(params.delayTime / 1000);
    this.audioEngine.setDelayFeedback(params.delayFeedback / 100);
    this.audioEngine.setDelayMix(params.delayMix / 100);
    
    // ピッチは直接設定する方法がないので、UIの値だけ更新
    document.getElementById('pitch').value = params.pitch;
    document.getElementById('pitch-value').textContent = params.pitch;
  }
  
  // BPMとSwingから最適なエフェクトを自動判定
  suggestEffectByTempo() {
    const bpm = this.sequencer.bpm;
    const swing = this.sequencer.swing;
    
    if (bpm < 90) {
      // 遅いテンポ → 広がりのあるエフェクト
      return 'spacious';
    } else if (bpm > 150) {
      // 速いテンポ → 控えめなエフェクト
      return 'natural';
    } else if (swing > 30) {
      // Swingが大きい → 夢幻的
      return 'dreamy';
    } else {
      // 標準 → ナチュラル
      return 'natural';
    }
  }
  
  // スマートエフェクト（曲の特徴から自動判定）
  applySmartEffect() {
    const suggestion = this.suggestEffectByTempo();
    
    switch (suggestion) {
      case 'spacious':
        this.applyspaciousEffect();
        break;
      case 'dreamy':
        this.applyDreamyEffect();
        break;
      case 'natural':
      default:
        this.applyNaturalEffect();
        break;
    }
  }
}