// ==========================================
// パターンUI管理（改善版・わかりやすい）
// ==========================================

class PatternUI {
  constructor(patternManager, onPatternSwitch) {
    this.patternManager = patternManager;
    this.onPatternSwitch = onPatternSwitch;
    this.container = null;
  }
  

  
  // パターンボタン生成（改善版）
  _createPatternButton(pattern) {
    const btnContainer = document.createElement('div');
    btnContainer.className = 'pattern-btn-container';
    
    const btn = document.createElement('button');
    btn.className = 'pattern-btn';
    btn.dataset.pattern = pattern;
    
    if (pattern === this.patternManager.getCurrentPatternName()) {
      btn.classList.add('active');
    }
    
    const patternName = this.patternManager.patternNames[pattern];
    
    btn.innerHTML = `
      <div class="pattern-btn-letter">${pattern}</div>
      <div class="pattern-btn-name">${patternName}</div>
    `;
    
    btn.addEventListener('click', () => this.handlePatternSwitch(pattern));
    
    btnContainer.appendChild(btn);
    return btnContainer;
  }
  
  // イベントリスナー設定
  setupEventListeners() {
    // コピーボタン
    document.getElementById('pattern-copy-btn')?.addEventListener('click', () => {
      this.handleCopyPattern();
    });
    
    // クリアボタン
    document.getElementById('pattern-clear-btn')?.addEventListener('click', () => {
      this.handleClearPattern();
    });
    
    // 名前変更ボタン
    document.getElementById('pattern-rename-btn')?.addEventListener('click', () => {
      this.handleRenamePattern();
    });
  }
  
  // パターン切替ハンドラー
  handlePatternSwitch(patternName) {
    // 同じパターンをクリックした場合は何もしない
    if (patternName === this.patternManager.getCurrentPatternName()) {
      return;
    }
    
    // 切替前処理
    if (this.onPatternSwitch) {
      this.onPatternSwitch('beforeSwitch', patternName);
    }
    
    // パターンを切替
    const success = this.patternManager.switchPattern(patternName);
    
    if (success) {
      // ボタンのアクティブ状態を更新
      this.updateActiveButton(patternName);
      
      // 現在のパターン名を更新
      this.updateCurrentPatternDisplay();
      
      // 切替後処理
      if (this.onPatternSwitch) {
        this.onPatternSwitch('afterSwitch', patternName);
      }
      
      // ステータス表示
      this.showStatus(`✅ ${this.patternManager.patternNames[patternName]} に切り替えました`);
    }
  }
  
  // アクティブボタンを更新
  updateActiveButton(patternName) {
    const buttons = this.container.querySelectorAll('.pattern-btn');
    buttons.forEach(btn => {
      if (btn.dataset.pattern === patternName) {
        btn.classList.add('active');
      } else {
        btn.classList.remove('active');
      }
    });
  }
  
  // 現在のパターン表示を更新
  updateCurrentPatternDisplay() {
    const display = document.getElementById('current-pattern-name');
    if (display) {
      const currentPattern = this.patternManager.getCurrentPatternName();
      display.textContent = this.patternManager.patternNames[currentPattern];
    }
  }
  
  // パターンコピーハンドラー
  handleCopyPattern() {
    const currentPattern = this.patternManager.getCurrentPatternName();
    const currentName = this.patternManager.patternNames[currentPattern];
    
    // カスタムダイアログを表示
    this.showCopyDialog(currentPattern, currentName);
  }
  
  // コピーダイアログ表示
  showCopyDialog(fromPattern, fromName) {
    const modal = document.createElement('div');
    modal.className = 'pattern-modal';
    modal.innerHTML = `
      <div class="pattern-modal-content">
        <h3>📋 パターンをコピー</h3>
        <p class="modal-description">
          <strong>${fromName}</strong> をどこにコピーしますか？
        </p>
        <div class="copy-target-buttons">
          ${['A', 'B', 'C', 'D']
            .filter(p => p !== fromPattern)
            .map(p => `
              <button class="copy-target-btn" data-target="${p}">
                <div class="target-letter">${p}</div>
                <div class="target-name">${this.patternManager.patternNames[p]}</div>
              </button>
            `).join('')}
        </div>
        <button class="modal-cancel-btn">キャンセル</button>
      </div>
    `;
    
    document.body.appendChild(modal);
    
    // ターゲットボタンのイベント
    modal.querySelectorAll('.copy-target-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        const target = btn.dataset.target;
        const success = this.patternManager.copyPattern(fromPattern, target);
        if (success) {
          this.showStatus(`✅ ${target} にコピーしました`);
          this.patternManager.saveToLocalStorage();
        }
        document.body.removeChild(modal);
      });
    });
    
    // キャンセルボタン
    modal.querySelector('.modal-cancel-btn').addEventListener('click', () => {
      document.body.removeChild(modal);
    });
    
    // 背景クリック
    modal.addEventListener('click', (e) => {
      if (e.target === modal) {
        document.body.removeChild(modal);
      }
    });
  }
  
  // パターンクリアハンドラー
  handleClearPattern() {
    const currentPattern = this.patternManager.getCurrentPatternName();
    const currentName = this.patternManager.patternNames[currentPattern];
    
    const confirmed = confirm(
      `本当に「${currentName}」をクリアしますか？\n\nこの操作は取り消せません。`
    );
    
    if (confirmed) {
      const success = this.patternManager.clearPattern(currentPattern);
      if (success) {
        this.showStatus(`🗑️ ${currentName} をクリアしました`);
        
        // UIを更新
        if (this.onPatternSwitch) {
          this.onPatternSwitch('afterClear', currentPattern);
        }
        
        this.patternManager.saveToLocalStorage();
      }
    }
  }
  
  // パターン名変更ハンドラー
  handleRenamePattern() {
    const currentPattern = this.patternManager.getCurrentPatternName();
    const currentName = this.patternManager.patternNames[currentPattern];
    
    const newName = prompt(
      `パターン ${currentPattern} の新しい名前を入力してください:\n\n（例: イントロ、サビ、アウトロ など）`,
      currentName
    );
    
    if (newName && newName.trim() !== '') {
      const success = this.patternManager.renamePattern(currentPattern, newName.trim());
      if (success) {
        this.updateCurrentPatternDisplay();
        this.updatePatternButtonNames();
        this.showStatus(`✏️ "${newName.trim()}" に変更しました`);
        this.patternManager.saveToLocalStorage();
      }
    }
  }
  
  // パターンボタンの名前を更新
  updatePatternButtonNames() {
    const buttons = this.container.querySelectorAll('.pattern-btn');
    buttons.forEach(btn => {
      const pattern = btn.dataset.pattern;
      const nameElement = btn.querySelector('.pattern-btn-name');
      if (nameElement) {
        nameElement.textContent = this.patternManager.patternNames[pattern];
      }
    });
  }
  
  // ステータスメッセージを表示
  showStatus(message) {
    const statusDiv = document.getElementById('status');
    if (statusDiv) {
      statusDiv.textContent = message;
      statusDiv.style.display = 'block';
      setTimeout(() => {
        statusDiv.style.display = 'none';
      }, 2000);
    } else {
      console.log('Status:', message);
    }
  }
}