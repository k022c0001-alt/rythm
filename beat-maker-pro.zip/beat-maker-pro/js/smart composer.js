// ==========================================
// スマート作曲システム（密度調整 ＋ JSON保存 統合版）
// ==========================================

class SmartComposer {
  constructor(app) {
    this.app = app;
    this.uiManager = app.uiManager;
    this.sequencer = app.sequencer;
    this.audioEngine = app.audioEngine;
    
    // 感情パラメータ
    this.gentleness = 50;    // やさしさ
    this.darkness = 50;      // 暗さ
    this.ephemerality = 50;  // はかなさ
    
    // 密度設定 (新規機能)
    this.densityLevel = 'normal'; // 'sparse', 'normal', 'dense'
    
    // 現在のジャンル
    this.currentGenre = 'pop';
  }
  
  // ==========================================
  // ジャンル別のルール定義
  // ==========================================
  
  getGenreRules(genre) {
    const rules = {
      pop: {
        name: 'ポップ',
        emoji: '🎵',
        bpmRange: [110, 140],
        instruments: {
          rhythm: ['Kick', 'Snare', 'HiHat'],
          melody: ['Bell', 'Harp', 'Whistle'],
          bass: ['Bass']
        },
        patterns: {
          kick: [1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0],
          snare: [0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0],
          hihat: [1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0]
        },
        density: 0.4,
        swing: [0, 10]
      },
      
      rock: {
        name: 'ロック',
        emoji: '🎸',
        bpmRange: [120, 160],
        instruments: {
          rhythm: ['Kick', 'Snare', 'HiHat', 'Cymbal', 'Tom'],
          melody: ['EGuitar', 'Zap'],
          bass: ['Bass', 'WobbleBass']
        },
        patterns: {
          kick: [1, 0, 0, 0, 1, 0, 1, 0, 1, 0, 0, 0, 1, 0, 1, 0],
          snare: [0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0],
          hihat: [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1]
        },
        density: 0.5,
        swing: [0, 5]
      },
      
      bossanova: {
        name: 'ボサノバ',
        emoji: '🌴',
        bpmRange: [100, 130],
        instruments: {
          rhythm: ['Rimshot', 'Clap', 'HiHat'],
          melody: ['Flute', 'Harp', 'Bell'],
          bass: ['Bass']
        },
        patterns: {
          kick: [1, 0, 0, 1, 0, 0, 1, 0, 1, 0, 0, 1, 0, 0, 1, 0],
          snare: [0, 0, 1, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 1, 0, 0],
          hihat: [1, 0, 0, 1, 0, 0, 1, 0, 1, 0, 0, 1, 0, 0, 1, 0]
        },
        density: 0.3,
        swing: [20, 40]
      },
      
      jazz: {
        name: 'ジャズ',
        emoji: '🎷',
        bpmRange: [90, 140],
        instruments: {
          rhythm: ['Rimshot', 'HiHat', 'Cymbal'],
          melody: ['Shinobue', 'Whistle', 'Harp'],
          bass: ['Bass']
        },
        patterns: {
          kick: [1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0],
          snare: [0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 1, 0, 0, 0, 0, 1],
          hihat: [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1]
        },
        density: 0.35,
        swing: [30, 50]
      },
      
      ambient: {
        name: 'アンビエント',
        emoji: '🌊',
        bpmRange: [60, 90],
        instruments: {
          rhythm: ['Cymbal', 'Cowbell'],
          melody: ['DarkPad', 'Drone', 'Bell', 'Harp'],
          bass: ['Drone']
        },
        patterns: {
          kick: [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
          snare: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
          hihat: [0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0]
        },
        density: 0.15,
        swing: [0, 20]
      },
      
      electronic: {
        name: 'エレクトロニック',
        emoji: '⚡',
        bpmRange: [120, 140],
        instruments: {
          rhythm: ['Kick', 'Snare', 'HiHat', 'Clap', 'Glitch'],
          melody: ['Zap', 'WobbleBass', 'Glitch'],
          bass: ['WobbleBass']
        },
        patterns: {
          kick: [1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0],
          snare: [0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0],
          hihat: [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1]
        },
        density: 0.45,
        swing: [0, 15]
      }
    };
    
    return rules[genre] || rules.pop;
  }
  
  // 密度係数を取得
  getDensityMultiplier() {
    switch (this.densityLevel) {
      case 'sparse':
        return 0.4;  // 少なめ（40%）
      case 'normal':
        return 1.0;  // 普通（100%）
      case 'dense':
        return 1.8;  // 多め（180%）
      default:
        return 1.0;
    }
  }

  // 密度の説明文
  getDensityText() {
    switch (this.densityLevel) {
      case 'sparse': return '・少なめ';
      case 'dense':  return '・多め';
      default:       return '';
    }
  }
  
  // ==========================================
  // スマート作曲メイン処理
  // ==========================================
  
  compose() {
    const genre = this.getGenreRules(this.currentGenre);
    
    // グリッドをクリア
    this.clearAllCells();
    
    // 密度係数を取得
    const densityMultiplier = this.getDensityMultiplier();
    
    // 1. リズムセクション作成（密度調整付き）
    this.createRhythmSection(genre, densityMultiplier);
    
    // 2. ベースライン作成（密度調整付き）
    this.createBassline(genre, densityMultiplier);
    
    // 3. メロディ作成（密度調整付き）
    this.createMelody(genre, densityMultiplier);
    
    // 4. BPMとSwing設定
    this.setBPMAndSwing(genre);
    
    // 5. エフェクト設定
    this.applyGenreEffect(genre);
    
    // ステータス表示
    const emotion = this.getEmotionDescription();
    const densityText = this.getDensityText();
    this.uiManager.showStatus(
      `${genre.emoji} ${genre.name}で${emotion}${densityText}な曲を作成しました！`,
      'success'
    );

    // ★自動保存を実行
    this.autoDownloadJSON(genre.name);
  }
  
  clearAllCells() {
    for (let row = 0; row < CONFIG.ROWS; row++) {
      for (let col = 0; col < CONFIG.COLS; col++) {
        const grid = this.uiManager.pages[this.uiManager.currentPageIndex].grid;
        if (grid[row][col]) {
          this.uiManager.toggleCell(row, col);
        }
      }
    }
  }
  
  // ==========================================
  // 各パート生成（密度調整対応）
  // ==========================================

  createRhythmSection(genre, densityMultiplier = 1.0) {
    const rhythmInstruments = genre.instruments.rhythm;
    
    rhythmInstruments.forEach(instrumentName => {
      const row = this.findInstrumentRow(instrumentName);
      if (row === -1) return;
      
      let pattern;
      if (instrumentName === 'Kick' && genre.patterns.kick) {
        pattern = genre.patterns.kick;
      } else if (instrumentName === 'Snare' && genre.patterns.snare) {
        pattern = genre.patterns.snare;
      } else if (instrumentName === 'HiHat' && genre.patterns.hihat) {
        pattern = genre.patterns.hihat;
      } else {
        pattern = this.generateRhythmPattern(genre.density * densityMultiplier);
      }
      
      pattern.forEach((shouldPlace, col) => {
        const ephemeralityFactor = 1 - (this.ephemerality / 200);
        
        // 密度調整: densityMultiplierを適用
        const finalProbability = ephemeralityFactor * densityMultiplier;
        
        if (shouldPlace && Math.random() < finalProbability) {
          this.uiManager.toggleCell(row, col, 0);
        }
      });
    });
  }
  
  generateRhythmPattern(baseDensity) {
    const pattern = [];
    const gentlenessFactor = 1 - (this.gentleness / 200);
    const adjustedDensity = baseDensity * gentlenessFactor;
    
    for (let i = 0; i < CONFIG.COLS; i++) {
      pattern.push(Math.random() < adjustedDensity ? 1 : 0);
    }
    
    return pattern;
  }
  
  createBassline(genre, densityMultiplier = 1.0) {
    const bassInstruments = genre.instruments.bass;
    const bassName = bassInstruments[Math.floor(Math.random() * bassInstruments.length)];
    const row = this.findInstrumentRow(bassName);
    
    if (row === -1) return;
    
    const darknessFactor = 0.5 + (this.darkness / 200);
    // 密度調整
    const bassDensity = 0.25 * darknessFactor * densityMultiplier;
    
    const noteRange = this.darkness > 50 ? [0, 2] : [0, 4];
    
    for (let col = 0; col < CONFIG.COLS; col += 2) {
      if (Math.random() < bassDensity) {
        const noteIndex = noteRange[0] + Math.floor(Math.random() * (noteRange[1] - noteRange[0] + 1));
        this.uiManager.toggleCell(row, col, noteIndex);
      }
    }
  }
  
  createMelody(genre, densityMultiplier = 1.0) {
    const melodyInstruments = genre.instruments.melody;
    
    const numInstruments = Math.floor(1 + (this.gentleness / 50));
    
    for (let i = 0; i < Math.min(numInstruments, melodyInstruments.length); i++) {
      const instrumentName = melodyInstruments[i];
      const row = this.findInstrumentRow(instrumentName);
      
      if (row === -1) continue;
      
      this.createMelodyLine(row, genre, densityMultiplier);
    }
  }
  
  createMelodyLine(row, genre, densityMultiplier = 1.0) {
    const instrument = CONFIG.INSTRUMENTS[row];
    
    const baseDensity = genre.density * 0.5;
    const ephemeralityFactor = 1 - (this.ephemerality / 150);
    // 密度調整
    const melodyDensity = baseDensity * ephemeralityFactor * densityMultiplier;
    
    let noteRange;
    if (this.darkness > 60) {
      noteRange = [0, 4];
    } else if (this.gentleness > 60) {
      noteRange = [4, 9];
    } else {
      noteRange = [7, 12];
    }
    
    if (instrument.isMelodic) {
      const scale = this.getScale();
      let lastNote = scale[Math.floor(scale.length / 2)];
      
      for (let col = 0; col < CONFIG.COLS; col++) {
        if (Math.random() < melodyDensity) {
          const step = Math.floor(Math.random() * 5) - 2;
          const noteIndex = Math.max(noteRange[0], Math.min(noteRange[1], lastNote + step));
          
          this.uiManager.toggleCell(row, col, noteIndex);
          lastNote = noteIndex;
        }
      }
    }
  }
  
  getScale() {
    if (this.darkness > 60) {
      return [0, 2, 3, 5, 7, 8, 10];
    } else if (this.gentleness > 60) {
      return [0, 2, 4, 7, 9];
    } else {
      return [0, 2, 4, 5, 7, 9, 11];
    }
  }
  
  // ==========================================
  // BPM・エフェクト設定
  // ==========================================

  setBPMAndSwing(genre) {
    let bpm = genre.bpmRange[0] + Math.random() * (genre.bpmRange[1] - genre.bpmRange[0]);
    bpm -= (this.ephemerality / 100) * 20;
    bpm -= (this.darkness / 100) * 15;
    bpm = Math.round(Math.max(60, Math.min(200, bpm)));
    
    let swing = genre.swing[0] + Math.random() * (genre.swing[1] - genre.swing[0]);
    swing += (this.gentleness / 100) * 10;
    swing = Math.round(Math.max(0, Math.min(50, swing)));
    
    this.uiManager.setParameters({ bpm, swing });
    this.sequencer.setBPM(bpm);
    this.sequencer.setSwing(swing);
  }
  
  applyGenreEffect(genre) {
    let effect;
    
    switch (this.currentGenre) {
      case 'pop':
        effect = { decay: 90, delayTime: 150, delayFeedback: 20, delayMix: 25, pitch: 0 };
        break;
      case 'rock':
        effect = { decay: 85, delayTime: 100, delayFeedback: 15, delayMix: 20, pitch: 0 };
        break;
      case 'bossanova':
        effect = { decay: 92, delayTime: 200, delayFeedback: 25, delayMix: 30, pitch: 0 };
        break;
      case 'jazz':
        effect = { decay: 88, delayTime: 180, delayFeedback: 22, delayMix: 28, pitch: 0 };
        break;
      case 'ambient':
        effect = { decay: 95, delayTime: 500, delayFeedback: 45, delayMix: 50, pitch: 2 };
        break;
      case 'electronic':
        effect = { decay: 87, delayTime: 250, delayFeedback: 30, delayMix: 35, pitch: 0 };
        break;
      default:
        effect = { decay: 90, delayTime: 150, delayFeedback: 20, delayMix: 25, pitch: 0 };
    }
    
    if (this.ephemerality > 70) {
      effect.delayMix += 15;
      effect.decay += 5;
    }
    
    if (this.darkness > 70) {
      effect.pitch -= 2;
    }
    
    if (this.gentleness > 70) {
      effect.delayFeedback += 10;
    }
    
    this.uiManager.setParameters(effect);
    this.audioEngine.setDecay(effect.decay / 100);
    this.audioEngine.setDelayTime(effect.delayTime / 1000);
    this.audioEngine.setDelayFeedback(effect.delayFeedback / 100);
    this.audioEngine.setDelayMix(effect.delayMix / 100);
  }
  
  // ==========================================
  // ユーティリティ & 保存機能
  // ==========================================

  findInstrumentRow(instrumentName) {
    return CONFIG.INSTRUMENTS.findIndex(inst => inst.name === instrumentName);
  }
  
  getEmotionDescription() {
    const parts = [];
    
    if (this.gentleness > 70) parts.push('やさしく');
    if (this.darkness > 70) parts.push('暗く');
    if (this.ephemerality > 70) parts.push('はかない');
    
    if (parts.length === 0) return 'バランスの取れた';
    return parts.join('');
  }
  
  setEmotion(gentleness, darkness, ephemerality) {
    this.gentleness = Math.max(0, Math.min(100, gentleness));
    this.darkness = Math.max(0, Math.min(100, darkness));
    this.ephemerality = Math.max(0, Math.min(100, ephemerality));
  }
  
  setGenre(genre) {
    this.currentGenre = genre;
  }
  
  // 密度を設定
  setDensity(density) {
    this.densityLevel = density; // 'sparse', 'normal', 'dense'
  }

  // ★ JSON自動ダウンロード機能 (統合済み)
  autoDownloadJSON(genreName) {
    // 1. 保存するデータを収集
    const exportData = {
      info: {
        version: "2.2", // 密度対応版としてバージョンアップ
        generatedBy: "SmartComposer",
        genre: genreName,
        date: new Date().toISOString(),
        emotion: {
          gentleness: this.gentleness,
          darkness: this.darkness,
          ephemerality: this.ephemerality
        },
        density: this.densityLevel // ★密度設定も保存
      },
      // 楽譜データ（全ページ）
      pages: this.uiManager.getAllPageData(), 
      // BPM, Swing, エフェクト設定
      settings: this.uiManager.getParameters(), 
      // 各トラックの音量・ピッチ
      tracks: this.uiManager.getTrackSettings() 
    };

    // 2. JSON文字列に変換
    const jsonString = JSON.stringify(exportData, null, 2);

    // 3. ダウンロード用リンクを作成して自動クリック
    const blob = new Blob([jsonString], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
    // ファイル名に密度情報も含める
    a.href = url;
    a.download = `SmartCompose_${genreName}_${this.densityLevel}_${timestamp}.json`;
    
    document.body.appendChild(a);
    a.click();
    
    // 4. お掃除
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    
    console.log(`🎹 自動生成された曲(${this.densityLevel})をJSONとして保存しました`);
  }
}