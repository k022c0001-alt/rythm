// ==========================================
// シーケンサーのコアロジック
// ==========================================

class Sequencer {
  constructor(audioEngine, uiManager) {
    this.audioEngine = audioEngine;
    this.uiManager = uiManager;
    
    this.isPlaying = false;
    
    // 現在のステップ位置（曲全体を通しての通算ステップ数）
    this.currentStep = 0;
    
    this.nextNoteTime = 0;
    this.bpm = CONFIG.DEFAULT_BPM;
    this.swing = CONFIG.DEFAULT_SWING;
    
    this.timerID = null;
    
    // Mute/Solo状態
    this.muteStates = new Array(CONFIG.ROWS).fill(false);
    this.soloStates = new Array(CONFIG.ROWS).fill(false);
  }
  
  // 再生/停止トグル
  toggle() {
    if (this.isPlaying) {
      this.stop();
    } else {
      this.start();
    }
  }
  
  // 再生開始
  start() {
    if (this.isPlaying) return;
    
    if (this.audioEngine.audioContext.state === 'suspended') {
      this.audioEngine.audioContext.resume();
    }
    
    this.isPlaying = true;
    this.currentStep = 0;
    this.nextNoteTime = this.audioEngine.audioContext.currentTime + 0.1;
    this.scheduler();
  }
  
  // 停止
  stop() {
    this.isPlaying = false;
    this.currentStep = 0;
    // UIのハイライトを消す（-1を渡す）
    this.uiManager.updateStepIndicator(-1);
    
    if (this.timerID) {
      clearTimeout(this.timerID);
      this.timerID = null;
    }
  }
  
  // BPM設定
  setBPM(bpm) {
    this.bpm = bpm;
  }
  
  // Swing設定
  setSwing(swing) {
    this.swing = swing;
  }
  
  // Mute状態トグル
  toggleMute(track) {
    this.muteStates[track] = !this.muteStates[track];
    
    // Solo状態があればMuteは無効（Solo優先）
    if (this.soloStates.some(s => s)) {
      return;
    }
  }
  
  // Solo状態トグル
  toggleSolo(track) {
    this.soloStates[track] = !this.soloStates[track];
  }
  
  // トラックが再生可能か判定
  isTrackPlayable(track) {
    // Soloがある場合
    if (this.soloStates.some(s => s)) {
      return this.soloStates[track];
    }
    
    // Muteチェック
    return !this.muteStates[track];
  }
  
 // 次のノートをスケジュール
  scheduleNote(step, time) {
    // ----------------------------------------------------
    // 1. 位置計算
    // ----------------------------------------------------
    const stepsPerPage = CONFIG.COLS; // 16
    const pageIndex = Math.floor(step / stepsPerPage); // 現在のページ (0, 1, 2...)
    const stepInPage = step % stepsPerPage;            // ページ内のステップ (0~15)
    
    // 現在の時間との差分（待ち時間）を計算
    const currentTime = this.audioEngine.audioContext.currentTime;
    const drawTime = time - currentTime;

    // ----------------------------------------------------
    // 2. UI更新（ページめくり ＆ ハイライト）
    //    ★ここを完全に同期させます
    // ----------------------------------------------------
    if (drawTime > 0) {
      setTimeout(() => {
        // ▼▼▼ ログ出力エリア ▼▼▼
        console.group(`🎵 Step Execution: Page ${pageIndex + 1}, Step ${stepInPage + 1}`);
        console.log(`Time: ${this.audioEngine.audioContext.currentTime.toFixed(3)}s`);
        
        // A. ページ切り替えチェック
        const currentUIPage = this.uiManager.currentPageIndex;
        if (currentUIPage !== pageIndex) {
            console.log(`🔄 ページ切り替え発生: ${currentUIPage + 1}ページ目 → ${pageIndex + 1}ページ目`);
            
            // ページを切り替える
            const diff = pageIndex - currentUIPage;
            if (typeof this.uiManager.changePage === 'function') {
                this.uiManager.changePage(diff);
            }
        } else {
            console.log(`➡️ ページ切り替えなし（現在のページで継続）`);
        }

        // B. ハイライト処理
        console.log(`💡 ハイライト処理を実行します...`);
        
        if (this.uiManager.updateStepIndicator.length > 1) {
          this.uiManager.updateStepIndicator(stepInPage, pageIndex);
        } else {
          this.uiManager.updateStepIndicator(stepInPage);
        }
        
        // ★ユーザーからのリクエスト: 確認用ログ
        console.log(`✨ 同じように光っていますか？: YES (Page:${pageIndex + 1}, Step:${stepInPage + 1})`);
        console.groupEnd();
        // ▲▲▲ ログ出力エリア終了 ▲▲▲

      }, drawTime * 1000);
    }

    // ----------------------------------------------------
    // 3. トラックごとの再生処理（予約）
    //    （ここは変更なし）
    // ----------------------------------------------------
    for (let row = 0; row < CONFIG.ROWS; row++) {
      let isNoteOn = false;
      if (typeof this.uiManager.getNoteState === 'function') {
        isNoteOn = this.uiManager.getNoteState(pageIndex, row, stepInPage);
      } else if (pageIndex === 0 && this.uiManager.grid[row]) {
        isNoteOn = this.uiManager.grid[row][stepInPage];
      }

      if (!isNoteOn) continue;
      if (!this.isTrackPlayable(row)) continue;

      const instrument = CONFIG.INSTRUMENTS[row].name;
      const pitchSlider = document.querySelector(`.pitch-slider[data-track="${row}"]`);
      const volumeSlider = document.querySelector(`.volume-slider[data-track="${row}"]`);

      let pitchValue = pitchSlider ? parseFloat(pitchSlider.value) : 1.0;
      let volumeValue = volumeSlider ? parseFloat(volumeSlider.value) : 1.0;

      if (CONFIG.INSTRUMENTS[row].isMelodic) {
        let noteIndex = 0;
        if (typeof this.uiManager.getNoteData === 'function') {
          const data = this.uiManager.getNoteData(pageIndex, row, stepInPage);
          if (data != null) noteIndex = data;
        } else if (pageIndex === 0 && this.uiManager.noteData[row]) {
           const data = this.uiManager.noteData[row][stepInPage];
           if (data != null) noteIndex = data;
        }

        if (!CONFIG.NOTES[noteIndex]) noteIndex = 0;
        pitchValue *= CONFIG.NOTES[noteIndex].ratio;
      }

      this.audioEngine.playInstrument(instrument, time, {
        pitch: pitchValue,
        volume: volumeValue
      });
    }
  }
  // 次のノート時刻を計算
  nextNote() {
    const secondsPerBeat = 60.0 / this.bpm;
    // 16分音符の時間
    const sixteenthNote = secondsPerBeat / 4;
    
    // Swingを適用（偶数ステップは遅延）
    let noteLength = sixteenthNote;
    // グローバルステップではなく、小節内の偶奇で判断したほうが自然だが、
    // ここでは簡易的に現在のステップ数で判定
    if (this.currentStep % 2 === 1 && this.swing > 0) {
      const swingAmount = (this.swing / 100) * sixteenthNote;
      noteLength += swingAmount;
    }
    
    this.nextNoteTime += noteLength;
    
    this.currentStep++;
    
    // 総ページ数（設定がなければ1ページとする）
    // CONFIG.TOTAL_PAGES は config.js に定義することを推奨
    const totalPages = CONFIG.TOTAL_PAGES || 1;
    const maxSteps = CONFIG.COLS * totalPages;
    
    // 最大ステップに達したら0に戻る（ループ）
    if (this.currentStep >= maxSteps) {
      this.currentStep = 0;
    }
  }
  
  // スケジューラー（先読み方式）
  scheduler() {
    const scheduleAheadTime = CONFIG.SCHEDULE_AHEAD_TIME || 0.1;
    const currentTime = this.audioEngine.audioContext.currentTime;
    
    while (this.nextNoteTime < currentTime + scheduleAheadTime) {
      this.scheduleNote(this.currentStep, this.nextNoteTime);
      this.nextNote();
    }
    
    if (this.isPlaying) {
      this.timerID = setTimeout(() => this.scheduler(), 25);
    }
  }
}