// ==========================================
// UI生成と更新（改善版・マルチページ完全対応）
// ==========================================

class UIManager {
  constructor() {
    // ページ管理用の設定
    this.totalPages = CONFIG.TOTAL_PAGES || 4; 
    this.currentPageIndex = 0;
    
    // データ構造の初期化
    this.pages = [];
    this.initPages();
    
    this.currentStep = -1;
  }
  
  // ==========================================
  // 初期化メソッド
  // ==========================================
  
  // 全ページのデータ構造を初期化
  initPages() {
    this.pages = [];
    for (let p = 0; p < this.totalPages; p++) {
      this.pages.push({
        grid: this._createEmptyGridArray(false),
        noteData: this._createEmptyGridArray(0)
      });
    }
  }

  // 空のグリッド配列を作成するヘルパー（内部用）
  _createEmptyGridArray(defaultValue) {
    const arr = [];
    for (let row = 0; row < CONFIG.ROWS; row++) {
      arr[row] = [];
      for (let col = 0; col < CONFIG.COLS; col++) {
        arr[row][col] = defaultValue;
      }
    }
    return arr;
  }
  
  // ==========================================
  // DOM生成メソッド
  // ==========================================
  
  // グリッド生成（DOM描画）
  createGrid() {
    const gridContainer = document.getElementById('grid');
    if (!gridContainer) return;
    
    gridContainer.innerHTML = '';
    gridContainer.style.gridTemplateColumns = `repeat(${CONFIG.COLS}, 1fr)`;
    
    const currentGrid = this.pages[this.currentPageIndex].grid;
    const currentNoteData = this.pages[this.currentPageIndex].noteData;
    
    for (let row = 0; row < CONFIG.ROWS; row++) {
      for (let col = 0; col < CONFIG.COLS; col++) {
        const cell = this._createCell(row, col, currentGrid[row][col], currentNoteData[row][col]);
        gridContainer.appendChild(cell);
      }
    }

    this.updatePageIndicator();
  }
  
  // セル生成（内部用）
  _createCell(row, col, isActive, noteIndex) {
    const cell = document.createElement('div');
    cell.className = 'cell';
    cell.dataset.row = row;
    cell.dataset.col = col;
    cell.style.setProperty('--instrument-color', CONFIG.INSTRUMENTS[row].color);
    
    if (isActive) {
      cell.classList.add('active');
      
      // メロディ楽器の場合は音程表示
      if (CONFIG.INSTRUMENTS[row].isMelodic && CONFIG.NOTES[noteIndex]) {
        cell.textContent = CONFIG.NOTES[noteIndex].label;
        cell.style.fontSize = '0.7em';
        cell.style.fontWeight = 'bold';
      }
    }
    
    return cell;
  }

  // トラックラベル生成
  createTrackLabels() {
    const container = document.getElementById('track-labels');
    if (!container) return;
    
    container.innerHTML = '';
    
    CONFIG.INSTRUMENTS.forEach((instrument, index) => {
      const label = this._createTrackLabel(instrument, index);
      container.appendChild(label);
    });

    this._setupSettingsToggle(container);
  }
  
  // トラックラベル生成（内部用）
  _createTrackLabel(instrument, index) {
    const label = document.createElement('div');
    label.className = 'track-label';
    
    label.innerHTML = `
      <div class="track-info">
        <span class="track-emoji">${instrument.emoji}</span>
        <span class="track-name">${instrument.name}</span>
        <button class="mute-btn" data-track="${index}" title="Mute">M</button>
        <button class="solo-btn" data-track="${index}" title="Solo">S</button>
        <button class="settings-btn active" data-track="${index}" title="設定を閉じる">⚙️</button>
      </div>
      <div class="track-controls" id="track-controls-${index}" style="display: flex;">
        <div class="track-slider">
          <label class="slider-label">Pitch</label>
          <input type="range" class="pitch-slider" data-track="${index}" 
                 min="0.5" max="2.0" step="0.1" value="1.0">
          <span class="slider-value" id="pitch-value-${index}">1.0x</span>
        </div>
        <div class="track-slider">
          <label class="slider-label">Vol</label>
          <input type="range" class="volume-slider" data-track="${index}" 
                 min="0" max="2.0" step="0.1" value="1.0">
          <span class="slider-value" id="volume-value-${index}">100%</span>
        </div>
      </div>
    `;
    
    return label;
  }
  
  // 設定ボタンの一括開閉ロジック（内部用）
  _setupSettingsToggle(container) {
    const allButtons = container.querySelectorAll('.settings-btn');
    const allControls = container.querySelectorAll('.track-controls');

    allButtons.forEach(btn => {
      btn.addEventListener('click', (e) => {
        const clickedIndex = e.target.dataset.track;
        const currentControl = document.getElementById(`track-controls-${clickedIndex}`);
        const isVisible = currentControl.style.display !== 'none';
        
        // 全トラックの状態を統一
        const targetDisplay = isVisible ? 'none' : 'flex';
        const targetActive = !isVisible;
        const targetTitle = isVisible ? "設定を開く" : "設定を閉じる";

        allControls.forEach(ctrl => ctrl.style.display = targetDisplay);
        allButtons.forEach(b => {
          b.classList.toggle('active', targetActive);
          b.title = targetTitle;
        });
      });
    });
  }
  
  // コントロール生成
  createControls() {
    const controls = document.getElementById('controls');
    if (!controls) return;
    
    controls.innerHTML = `
      ${this._createControlGroup('🎵 BPM', 'bpm', CONFIG.MIN_BPM, CONFIG.MAX_BPM, CONFIG.DEFAULT_BPM)}
      ${this._createControlGroup('🎶 Swing', 'swing', CONFIG.MIN_SWING, CONFIG.MAX_SWING, CONFIG.DEFAULT_SWING, '%')}
      ${this._createControlGroup('🎚️ Pitch', 'pitch', -12, 12, 0)}
      ${this._createControlGroup('⏱️ Decay', 'decay', 0, 100, 100, '%')}
      ${this._createControlGroup('🔁 Delay Time', 'delay-time', 0, 1000, 0)}
      ${this._createControlGroup('🔊 Delay Feedback', 'delay-feedback', 0, 100, 0, '%')}
      ${this._createControlGroup('🎛️ Delay Mix', 'delay-mix', 0, 100, 0, '%')}
    `;
  }
  
  // コントロールグループ生成（内部用）
  _createControlGroup(label, id, min, max, defaultValue, unit = '') {
    return `
      <div class="control-group">
        <label>${label}: <span id="${id}-value">${defaultValue}${unit}</span></label>
        <input type="range" id="${id}" min="${min}" max="${max}" value="${defaultValue}">
      </div>
    `;
  }
  
  // ==========================================
  // ページ操作メソッド
  // ==========================================
  
  // ページ切り替え処理
  changePage(direction) {
    const newIndex = this.currentPageIndex + direction;
    
    if (newIndex >= 0 && newIndex < this.totalPages) {
      this.currentPageIndex = newIndex;
      this.createGrid();
    }
  }
  
  // ページインジケーター更新
  // ui-manager.js

  // ページインジケーター更新（上下両方に対応）
  updatePageIndicator() {
    // 1. ページ番号表示の更新（全箇所）
    const indicators = document.querySelectorAll('.page-indicator');
    indicators.forEach(el => {
      el.textContent = `Page ${this.currentPageIndex + 1} / ${this.totalPages}`;
    });

    // 2. 「前へ」ボタンの有効/無効化（全箇所）
    const prevBtns = document.querySelectorAll('.prev-page-btn');
    prevBtns.forEach(btn => {
      btn.disabled = (this.currentPageIndex === 0);
    });

    // 3. 「次へ」ボタンの有効/無効化（全箇所）
    const nextBtns = document.querySelectorAll('.next-page-btn');
    nextBtns.forEach(btn => {
      btn.disabled = (this.currentPageIndex === this.totalPages - 1);
    });
  }
  // ==========================================
  // セル操作メソッド
  // ==========================================
  
  // セル状態トグル
  toggleCell(row, col, noteIndex = null) {
    const instrument = CONFIG.INSTRUMENTS[row];
    const cell = document.querySelector(`[data-row="${row}"][data-col="${col}"]`);
    if (!cell) return;
    
    const currentGrid = this.pages[this.currentPageIndex].grid;
    const currentNoteData = this.pages[this.currentPageIndex].noteData;

    // 既にアクティブ → 無効化
    if (currentGrid[row][col]) {
      currentGrid[row][col] = false;
      cell.classList.remove('active');
      cell.textContent = '';
      return;
    }
    
    // メロディ楽器 & 音程未指定 → ダイアログ表示
    if (instrument.isMelodic && noteIndex === null) {
      this.showNoteSelector(row, col);
      return;
    }
    
    // 有効化
    currentGrid[row][col] = true;
    cell.classList.add('active');
    
    // メロディ楽器の場合は音程を保存
    if (instrument.isMelodic && noteIndex !== null) {
      currentNoteData[row][col] = noteIndex;
      if (CONFIG.NOTES[noteIndex]) {
        cell.textContent = CONFIG.NOTES[noteIndex].label;
        cell.style.fontSize = '0.7em';
        cell.style.fontWeight = 'bold';
      }
    }
  }
  
  // 音程選択ダイアログを表示
  showNoteSelector(row, col) {
    const modal = document.createElement('div');
    modal.className = 'note-selector-modal';
    modal.innerHTML = `
      <div class="note-selector-content">
        <h3>🎼 音程を選んでください</h3>
        <p class="note-hint">シャープ（♯）も選択できます</p>
        <div class="note-buttons">
          ${CONFIG.NOTES.map((note, index) => `
            <button class="note-btn ${note.name.includes('#') ? 'sharp' : ''}" 
                    data-note-index="${index}">
              ${note.label}
            </button>
          `).join('')}
        </div>
        <button class="cancel-btn">キャンセル</button>
      </div>
    `;
    
    document.body.appendChild(modal);
    
    // イベントリスナー
    modal.querySelectorAll('.note-btn').forEach(btn => {
      btn.addEventListener('click', (e) => {
        const noteIndex = parseInt(e.target.dataset.noteIndex);
        this.toggleCell(row, col, noteIndex);
        document.body.removeChild(modal);
      });
    });
    
    modal.querySelector('.cancel-btn').addEventListener('click', () => {
      document.body.removeChild(modal);
    });
    
    modal.addEventListener('click', (e) => {
      if (e.target === modal) {
        document.body.removeChild(modal);
      }
    });
  }
  
  // グリッドクリア（現在のページのみ）
  clearGrid() {
    this.pages[this.currentPageIndex].grid = this._createEmptyGridArray(false);
    this.pages[this.currentPageIndex].noteData = this._createEmptyGridArray(0);
    
    const cells = document.querySelectorAll('.cell');
    cells.forEach(cell => {
      cell.classList.remove('active');
      cell.textContent = '';
    });
  }
  
  // ==========================================
  // ステップインジケーター
  // ==========================================
  
  // ステップインジケーター更新
  updateStepIndicator(step, playingPageIndex = 0) {
    // ハイライトをクリア
    const currentCells = document.querySelectorAll('.cell.current');
    currentCells.forEach(cell => cell.classList.remove('current'));
    
    // 停止信号
    if (step === -1) {
      this.currentStep = -1;
      return;
    }
    
    // 再生中のページと表示中のページが一致する場合のみハイライト
    if (playingPageIndex === this.currentPageIndex) {
      const targetCells = document.querySelectorAll(`[data-col="${step}"]`);
      targetCells.forEach(cell => cell.classList.add('current'));
    }
    
    this.currentStep = step;
  }
  
  // ==========================================
  // データアクセスメソッド（Sequencer用）
  // ==========================================
  
  // 指定ページのON/OFF状態を取得
  getNoteState(pageIndex, row, step) {
    if (this.pages[pageIndex] && this.pages[pageIndex].grid) {
      return this.pages[pageIndex].grid[row][step];
    }
    return false;
  }

  // 指定ページの音程データを取得
  getNoteData(pageIndex, row, step) {
    // 引数なし → 現在のページの全データ
    if (pageIndex === undefined) {
      return this.pages[this.currentPageIndex].noteData;
    }

    // 特定のセル
    if (this.pages[pageIndex] && this.pages[pageIndex].noteData) {
      return this.pages[pageIndex].noteData[row][step];
    }
    return 0;
  }

  // 現在のページのグリッド全データを取得（互換性用）
  getGrid() {
    return this.pages[this.currentPageIndex].grid;
  }
  
  // ==========================================
  // 保存/読込用メソッド（マルチページ対応）
  // ==========================================

  // 全ページデータを取得
  getAllPageData() {
    return {
      grid: this.pages.map(p => p.grid),
      noteData: this.pages.map(p => p.noteData)
    };
  }

  // 全ページデータを設定（ロード時）
  setAllPageData(gridData, noteData) {
    if (!Array.isArray(gridData)) return;

    // 3次元配列（複数ページ）か2次元配列（1ページ）かを判定
    const isMultiPage = Array.isArray(gridData[0]) && Array.isArray(gridData[0][0]);
    
    if (isMultiPage) {
      // 新データ（3次元配列）
      this.totalPages = gridData.length;
      this.pages = [];
      
      for (let i = 0; i < this.totalPages; i++) {
        this.pages.push({
          grid: gridData[i],
          noteData: noteData ? noteData[i] : this._createEmptyGridArray(0)
        });
      }
    } else {
      // 旧データ（2次元配列）→ 0ページ目にロード
      this.pages[0].grid = gridData;
      if (noteData) this.pages[0].noteData = noteData;
    }

    // 表示をリセット
    this.currentPageIndex = 0;
    this.createGrid();
    this.showStatus('データ復元完了 (全ページ)', 'success');
  }

  // 1ページのみのグリッド設定（互換性用）
  setGrid(gridData, noteData = null) {
    this.pages[this.currentPageIndex].grid = gridData;
    if (noteData) {
      this.pages[this.currentPageIndex].noteData = noteData;
    }
    this.createGrid();
  }
  
  // ==========================================
  // パラメータ管理メソッド
  // ==========================================

  // パラメータ値を取得
  getParameters() {
    return {
      bpm: parseInt(document.getElementById('bpm')?.value || CONFIG.DEFAULT_BPM),
      swing: parseInt(document.getElementById('swing')?.value || CONFIG.DEFAULT_SWING),
      pitch: parseInt(document.getElementById('pitch')?.value || 0),
      decay: parseInt(document.getElementById('decay')?.value || 100),
      delayTime: parseInt(document.getElementById('delay-time')?.value || 0),
      delayFeedback: parseInt(document.getElementById('delay-feedback')?.value || 0),
      delayMix: parseInt(document.getElementById('delay-mix')?.value || 0)
    };
  }
  
  // パラメータ値を設定
  setParameters(params) {
    this._setParam('bpm', params.bpm);
    this._setParam('swing', params.swing, '%');
    this._setParam('pitch', params.pitch);
    this._setParam('decay', params.decay, '%');
    this._setParam('delay-time', params.delayTime);
    this._setParam('delay-feedback', params.delayFeedback, '%');
    this._setParam('delay-mix', params.delayMix, '%');
  }
  
  // パラメータ設定ヘルパー（内部用）
  _setParam(id, value, unit = '') {
    if (value === undefined) return;
    
    const input = document.getElementById(id);
    const display = document.getElementById(`${id}-value`);
    
    if (input) input.value = value;
    if (display) display.textContent = value + unit;
  }
  
  // トラック設定を取得
  getTrackSettings() {
    const settings = [];
    for (let i = 0; i < CONFIG.ROWS; i++) {
      const pitchSlider = document.querySelector(`.pitch-slider[data-track="${i}"]`);
      const volumeSlider = document.querySelector(`.volume-slider[data-track="${i}"]`);
      settings.push({
        pitch: pitchSlider ? parseFloat(pitchSlider.value) : 1.0,
        volume: volumeSlider ? parseFloat(volumeSlider.value) : 1.0
      });
    }
    return settings;
  }
  
  // トラック設定を設定
  setTrackSettings(settings) {
    settings.forEach((setting, index) => {
      const pitchSlider = document.querySelector(`.pitch-slider[data-track="${index}"]`);
      const volumeSlider = document.querySelector(`.volume-slider[data-track="${index}"]`);
      const pitchValue = document.getElementById(`pitch-value-${index}`);
      const volumeValue = document.getElementById(`volume-value-${index}`);
      
      if (pitchSlider && setting.pitch !== undefined) {
        pitchSlider.value = setting.pitch;
        if (pitchValue) pitchValue.textContent = setting.pitch + 'x';
      }
      
      if (volumeSlider && setting.volume !== undefined) {
        volumeSlider.value = setting.volume;
        if (volumeValue) volumeValue.textContent = Math.round(setting.volume * 100) + '%';
      }
    });
  }
  
  // ==========================================
  // ユーティリティメソッド
  // ==========================================
  
  // ステータス表示
  showStatus(message, type = 'info') {
    const status = document.getElementById('status');
    if (!status) return;
    
    status.textContent = message;
    status.className = `status ${type}`;
    
    setTimeout(() => {
      status.textContent = '';
      status.className = 'status';
    }, 2000);
  }
  
  // 空のグリッド配列を作成（外部からも使えるように）
  createEmptyGridArray(defaultValue) {
    return this._createEmptyGridArray(defaultValue);
  }
  // ==========================================
  // パターンUIの初期化と表示
  // ==========================================
// ==========================================
  // パターンUIの初期化と表示 (修正版)
  // ==========================================
// ==========================================
  // パターンUIの初期化（シンプル版）
  // ==========================================
  initPatternUI() {
    const handlePatternSwitch = (event, patternName) => {
      if (event === 'beforeSwitch') {
        this.saveCurrentPatternToManager();
      } else if (event === 'afterSwitch') {
        this.loadPatternFromManager();
        if (this.autoEffectAdjuster && typeof this.autoEffectAdjuster.analyze === 'function') {
           this.autoEffectAdjuster.analyze();
        }
      } else if (event === 'afterClear') {
        this.loadPatternFromManager();
      }
    };
    
    // PatternUI クラスのチェック
    if (typeof PatternUI === 'undefined' || !this.patternManager) {
        console.warn("PatternUI or PatternManager is missing.");
        return;
    }

    // インスタンス作成
    this.patternUI = new PatternUI(this.patternManager, handlePatternSwitch);
    
    // ★ HTMLで作った「専用の場所」を探す
    const mountPoint = document.getElementById('pattern-ui-mount-point');
    
    if (mountPoint) {
      // 念のため中身を一度クリア（重複防止）
      mountPoint.innerHTML = ''; 
      
      // その場所にUIを作成して入れる
      this.patternUI.create(mountPoint);
    } else {
      console.error("Error: Element #pattern-ui-mount-point not found in HTML.");
    }
  }
  init() {
    // ... 他の初期化コード ...

    // ★ この1行が必須です！
    this.initPatternUI(); 
  }
}