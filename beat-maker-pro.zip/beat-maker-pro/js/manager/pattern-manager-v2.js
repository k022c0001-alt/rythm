// ==========================================
// パターン管理クラス（マルチページ対応版・修正版）
// ==========================================

class PatternManager {
  constructor() {
    // 4つのパターンスロット（A, B, C, D）
    this.patterns = {
      A: this.createEmptyPattern(),
      B: this.createEmptyPattern(),
      C: this.createEmptyPattern(),
      D: this.createEmptyPattern()
    };
    
    this.currentPattern = 'A';
    this.patternNames = {
      A: '✨ やさしいパターン',
      B: '👻 暗いパターン',
      C: '🎸 ロックパターン',
      D: '🌊 アンビエント'
    };
    
    this.totalPages = CONFIG.TOTAL_PAGES || 4;
  }
  
  // 空のパターンを作成（全ページ分）
  createEmptyPattern() {
    const pages = [];
    for (let p = 0; p < this.totalPages; p++) {
      pages.push({
        grid: Array(CONFIG.ROWS).fill(null).map(() => Array(CONFIG.COLS).fill(false)),
        noteData: Array(CONFIG.ROWS).fill(null).map(() => Array(CONFIG.COLS).fill(-1))
      });
    }
    
    return {
      pages: pages,
      parameters: {
        bpm: CONFIG.DEFAULT_BPM,
        swing: CONFIG.DEFAULT_SWING,
        delayTime: 0,
        delayFeedback: 0,
        delayMix: 0,
        pitch: 0,
        decay: 1
      },
      trackSettings: Array(CONFIG.ROWS).fill(null).map(() => ({ pitch: 1.0, volume: 1.0 })),
      muteStates: Array(CONFIG.ROWS).fill(false),
      soloStates: Array(CONFIG.ROWS).fill(false)
    };
  }
  
  // 現在のパターンを取得
  getCurrentPattern() {
    return this.patterns[this.currentPattern];
  }
  
  // 現在のパターン名を取得
  getCurrentPatternName() {
    return this.currentPattern;
  }
  
  // パターンを切り替え
  switchPattern(patternName) {
    if (!this.patterns[patternName]) {
      console.error(`Pattern ${patternName} does not exist`);
      return false;
    }
    
    this.currentPattern = patternName;
    return true;
  }
  
  // ★★★ 修正: 現在のパターンにデータを保存 ★★★
  saveCurrentPattern(pagesData, parameters, trackSettings, muteStates, soloStates) {
    // pagesData は配列で、各要素が { grid, noteData } を持つ
    try {
      this.patterns[this.currentPattern] = {
        pages: JSON.parse(JSON.stringify(pagesData)),
        parameters: { ...parameters },
        trackSettings: JSON.parse(JSON.stringify(trackSettings)),
        muteStates: [...muteStates],
        soloStates: [...soloStates]
      };
    } catch (error) {
      console.error('Error saving pattern:', error);
      console.log('pagesData:', pagesData);
    }
  }
  
  // パターンをコピー
  copyPattern(fromPattern, toPattern) {
    if (!this.patterns[fromPattern] || !this.patterns[toPattern]) {
      console.error('Invalid pattern name');
      return false;
    }
    
    this.patterns[toPattern] = JSON.parse(JSON.stringify(this.patterns[fromPattern]));
    return true;
  }
  
  // パターンをクリア
  clearPattern(patternName) {
    if (!this.patterns[patternName]) {
      console.error(`Pattern ${patternName} does not exist`);
      return false;
    }
    
    this.patterns[patternName] = this.createEmptyPattern();
    return true;
  }
  
  // パターン名を変更
  renamePattern(patternName, newName) {
    if (!this.patterns[patternName]) {
      console.error(`Pattern ${patternName} does not exist`);
      return false;
    }
    
    this.patternNames[patternName] = newName;
    return true;
  }
  
  // すべてのパターンを取得（JSON保存用）
  exportAllPatterns() {
    return {
      patterns: JSON.parse(JSON.stringify(this.patterns)),
      currentPattern: this.currentPattern,
      patternNames: { ...this.patternNames }
    };
  }
  
  // パターンをインポート（JSON読込用）
  importAllPatterns(data) {
    if (data.patterns) {
      this.patterns = JSON.parse(JSON.stringify(data.patterns));
    }
    if (data.currentPattern) {
      this.currentPattern = data.currentPattern;
    }
    if (data.patternNames) {
      this.patternNames = { ...data.patternNames };
    }
  }
  
  // LocalStorage用のキー
  getStorageKey() {
    return 'beatMakerPro_allPatterns_v2';
  }
  
  // LocalStorageに保存
  saveToLocalStorage() {
    try {
      const data = this.exportAllPatterns();
      localStorage.setItem(this.getStorageKey(), JSON.stringify(data));
      return true;
    } catch (e) {
      console.error('Failed to save patterns to localStorage:', e);
      return false;
    }
  }
  
  // LocalStorageから読込
  loadFromLocalStorage() {
    try {
      const data = localStorage.getItem(this.getStorageKey());
      if (data) {
        this.importAllPatterns(JSON.parse(data));
        return true;
      }
      return false;
    } catch (e) {
      console.error('Failed to load patterns from localStorage:', e);
      return false;
    }
  }
}