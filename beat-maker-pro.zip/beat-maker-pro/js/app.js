// ==========================================
// メインアプリケーション（完全統合・修正版）
// ==========================================

class BeatMakerApp {
  constructor() {
    this.audioEngine = new AudioEngine();
    this.storageManager = new StorageManager();
    this.uiManager = new UIManager();
    this.sequencer = new Sequencer(this.audioEngine, this.uiManager);
    
    // ★★★ パターンマネージャー ★★★
    this.patternManager = new PatternManager();
    this.patternUI = null;
    
    // ★★★ 感情的ランダマイザー ★★★
    this.emotionalRandomizer = null;

    // ★★★ スマートコンポーザー ★★★
    this.smartComposer = null;
    this.smartComposerUI = null;

    // ★★★ 自動エフェクト調整 ★★★
    this.autoEffectAdjuster = null;
    
    this.init();
  }
  
  // 初期化
  init() {
    this.uiManager.createGrid();
    this.uiManager.createTrackLabels();
    this.uiManager.createControls();
    
    // 各機能の初期化
    this.initPatternUI();
    this.initEmotionalRandomizer();
    this.initSmartComposer();
    this.initAutoEffectAdjuster();
    
    // イベントリスナーの設定（ここが重要）
    this.setupEventListeners();
    
    // 全パターンをロード
    this.loadAllPatternsFromStorage();
  }
  
  // パターンUIの初期化
  initPatternUI() {
    const handlePatternSwitch = (event, patternName) => {
      if (event === 'beforeSwitch') {
        this.saveCurrentPatternToManager();
      } else if (event === 'afterSwitch') {
        this.loadPatternFromManager();
        // エフェクト自動調整の更新
        if (this.autoEffectAdjuster && typeof this.autoEffectAdjuster.analyze === 'function') {
            this.autoEffectAdjuster.analyze();
        }
      } else if (event === 'afterClear') {
        this.loadPatternFromManager();
      }
    };
    
    this.patternUI = new PatternUI(this.patternManager, handlePatternSwitch);
    
    const controlsDiv = document.getElementById('controls');
    // if (controlsDiv && controlsDiv.parentElement) {
    //   // 既存のUIがあれば削除（重複防止）
    //   const existingUI = document.getElementById('pattern-ui');
    //   if (existingUI) existingUI.remove();

    //    this.patternUI.create(controlsDiv.parentElement);
    //   controlsDiv.parentElement.insertBefore(
    //     document.getElementById('pattern-ui'),
    //     controlsDiv
    //   );
    // }
  }
  
  // 感情的ランダマイザーの初期化
  initEmotionalRandomizer() {
    if (typeof EmotionalRandomizer !== 'undefined') {
        this.emotionalRandomizer = new EmotionalRandomizer(this);
        this.emotionalRandomizer.createUI();
    }
  }

  // スマートコンポーザーの初期化
  initSmartComposer() {
    if (typeof SmartComposer !== 'undefined' && typeof SmartComposerUI !== 'undefined') {
        this.smartComposer = new SmartComposer(this);
        this.smartComposerUI = new SmartComposerUI(this.smartComposer);
        this.smartComposerUI.createUI();
    }
  }

  // 自動エフェクト調整の初期化
  initAutoEffectAdjuster() {
    if (typeof AutoEffectAdjuster !== 'undefined') {
        this.autoEffectAdjuster = new AutoEffectAdjuster(this);
        if (typeof this.autoEffectAdjuster.init === 'function') {
            this.autoEffectAdjuster.init();
        }
    }
  }
  
  // 現在のパターンをPatternManagerに保存
  saveCurrentPatternToManager() {
    const allPageData = this.uiManager.getAllPageData();
    
    this.patternManager.saveCurrentPattern(
      allPageData.grid.map((grid, i) => ({
        grid: grid,
        noteData: allPageData.noteData[i]
      })),
      this.uiManager.getParameters(),
      this.uiManager.getTrackSettings(),
      this.sequencer.muteStates,
      this.sequencer.soloStates
    );
  }
  
  // PatternManagerからパターンを読み込み
  loadPatternFromManager() {
    const pattern = this.patternManager.getCurrentPattern();
    
    const gridData = pattern.pages.map(p => p.grid);
    const noteData = pattern.pages.map(p => p.noteData);
    this.uiManager.setAllPageData(gridData, noteData);
    
    this.uiManager.setParameters(pattern.parameters);
    this.sequencer.setBPM(pattern.parameters.bpm);
    this.sequencer.setSwing(pattern.parameters.swing);
    
    this.audioEngine.setDecay(pattern.parameters.decay);
    this.audioEngine.setDelayTime(pattern.parameters.delayTime / 1000);
    this.audioEngine.setDelayFeedback(pattern.parameters.delayFeedback / 100);
    this.audioEngine.setDelayMix(pattern.parameters.delayMix / 100);
    
    this.uiManager.setTrackSettings(pattern.trackSettings);
    
    this.sequencer.muteStates = [...pattern.muteStates];
    this.sequencer.soloStates = [...pattern.soloStates];
    
    this.updateMuteSoloButtons();
    
    this.uiManager.showStatus(
      `Loaded: ${this.patternManager.patternNames[this.patternManager.getCurrentPatternName()]}`,
      'success'
    );
  }
  
  // Mute/Soloボタンの表示を更新
  updateMuteSoloButtons() {
    this.sequencer.muteStates.forEach((muted, index) => {
      const btn = document.querySelector(`.mute-btn[data-track="${index}"]`);
      if (btn) btn.classList.toggle('active', muted);
    });
    
    this.sequencer.soloStates.forEach((soloed, index) => {
      const btn = document.querySelector(`.solo-btn[data-track="${index}"]`);
      if (btn) btn.classList.toggle('active', soloed);
    });
  }
  
  // 全パターンをLocalStorageから読み込み
  loadAllPatternsFromStorage() {
    const loaded = this.patternManager.loadFromLocalStorage();
    if (loaded) {
      this.loadPatternFromManager();
      console.log('All patterns loaded from localStorage');
    } else {
      this.saveCurrentPatternToManager();
      console.log('Initialized with default pattern A');
    }
  }
  
  // ==========================================
  // イベントリスナー設定（エラー対策済み）
  // ==========================================
  setupEventListeners() {
    // --- グリッドクリック ---
    const grid = document.getElementById('grid');
    if (grid) {
        grid.addEventListener('click', (e) => {
            if (e.target.classList.contains('cell')) {
                const row = parseInt(e.target.dataset.row);
                const col = parseInt(e.target.dataset.col);
                this.uiManager.toggleCell(row, col);
            }
        });
    }
    
    // --- 再生/停止 ---
    const playBtn = document.getElementById('play-btn');
    if (playBtn) {
        playBtn.addEventListener('click', () => {
            this.sequencer.toggle();
            playBtn.textContent = this.sequencer.isPlaying ? '⏹️ 停止' : '▶️ 再生';
            playBtn.classList.toggle('playing', this.sequencer.isPlaying);
        });
    }
    
    // --- クリア ---
    const clearBtn = document.getElementById('clear-btn');
    if (clearBtn) {
        clearBtn.addEventListener('click', () => {
            if (confirm('現在のページをクリアしますか？')) {
                this.uiManager.clearGrid();
                this.uiManager.showStatus('🗑️ クリアしました', 'success');
            }
        });
    }
    
    // --- ページ切り替え（一括設定） ---
    document.querySelectorAll('.prev-page-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            if (this.uiManager.changePage) this.uiManager.changePage(-1);
        });
    });

    document.querySelectorAll('.next-page-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            if (this.uiManager.changePage) this.uiManager.changePage(1);
        });
    });

    // --- 保存 (LocalStorage) ---
    // 元のコードでコメントアウトされていた部分を復活
    const saveBtn = document.getElementById('save-btn');
    if (saveBtn) {
        saveBtn.addEventListener('click', () => {
            this.saveData();
        });
    }
    
    // --- 読込 (LocalStorage) ---
    // 元のコードでコメントアウトされていた部分を復活
    const loadBtn = document.getElementById('load-btn');
    if (loadBtn) {
        loadBtn.addEventListener('click', () => {
            this.loadData();
        });
    }
    
    // --- JSONエクスポート ---
    const exportBtn = document.getElementById('export-json-btn');
    if (exportBtn) {
        exportBtn.addEventListener('click', () => {
            this.exportJSON();
        });
    }
    
    // --- JSONインポート（修正版） ---
    const importBtn = document.getElementById('import-json-btn');
    const fileInput = document.getElementById('json-file-input');

    if (importBtn && fileInput) {
        // ボタンを押したら隠しinputをクリックさせる
        importBtn.addEventListener('click', () => {
            fileInput.click();
        });
        
        // ファイルが選択されたら処理を実行
        fileInput.addEventListener('change', (e) => {
            this.handleFileSelect(e);
        });
    }

    // --- パラメータ変更 (ループで安全に設定) ---
    const params = [
        { id: 'bpm', action: (val) => { this.sequencer.setBPM(val); document.getElementById('bpm-value').textContent = val; } },
        { id: 'swing', action: (val) => { this.sequencer.setSwing(val); document.getElementById('swing-value').textContent = val + '%'; } },
        { id: 'pitch', action: (val) => { document.getElementById('pitch-value').textContent = val; } },
        { id: 'decay', action: (val) => { this.audioEngine.setDecay(val / 100); document.getElementById('decay-value').textContent = val + '%'; } },
        { id: 'delay-time', action: (val) => { this.audioEngine.setDelayTime(val / 1000); document.getElementById('delay-time-value').textContent = val; } },
        { id: 'delay-feedback', action: (val) => { this.audioEngine.setDelayFeedback(val / 100); document.getElementById('delay-feedback-value').textContent = val + '%'; } },
        { id: 'delay-mix', action: (val) => { this.audioEngine.setDelayMix(val / 100); document.getElementById('delay-mix-value').textContent = val + '%'; } }
    ];

    params.forEach(param => {
        const el = document.getElementById(param.id);
        if (el) {
            el.addEventListener('input', (e) => {
                param.action(parseInt(e.target.value));
            });
        }
    });
    
    // --- トラック操作 (委譲) ---
    const trackLabels = document.getElementById('track-labels');
    if (trackLabels) {
        // クリックイベント (Mute/Solo)
        trackLabels.addEventListener('click', (e) => {
            if (e.target.classList.contains('mute-btn')) {
                const track = parseInt(e.target.dataset.track);
                this.sequencer.toggleMute(track);
                e.target.classList.toggle('active');
            } else if (e.target.classList.contains('solo-btn')) {
                const track = parseInt(e.target.dataset.track);
                this.sequencer.toggleSolo(track);
                e.target.classList.toggle('active');
            }
        });

        // スライダーイベント
        trackLabels.addEventListener('input', (e) => {
            if (e.target.classList.contains('pitch-slider')) {
                const track = e.target.dataset.track;
                const value = parseFloat(e.target.value);
                const display = document.getElementById(`pitch-value-${track}`);
                if (display) display.textContent = value + 'x';
            } else if (e.target.classList.contains('volume-slider')) {
                const track = e.target.dataset.track;
                const value = parseFloat(e.target.value);
                const display = document.getElementById(`volume-value-${track}`);
                if (display) display.textContent = Math.round(value * 100) + '%';
            }
        });
    }
  }
  
  // JSONエクスポート（全パターン保存）
  exportJSON() {
    this.saveCurrentPatternToManager();
    
    const data = {
      version: '2.1',
      title: prompt('プロジェクト名を入力してください', 'My Beat Project') || 'My Beat Project',
      allPatterns: this.patternManager.exportAllPatterns(),
      timestamp: new Date().toISOString()
    };
    
    const jsonStr = JSON.stringify(data, null, 2);
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${data.title.replace(/[^a-zA-Z0-9]/g, '_')}_${Date.now()}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    
    this.uiManager.showStatus('📥 JSONエクスポート完了（全パターン）', 'success');
  }
  
  // JSONインポート処理（ファイル選択ハンドラ）
  handleFileSelect(e) {
    const file = e.target.files[0];
    if (!file) return;
    
    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const data = JSON.parse(event.target.result);
        
        // 新フォーマット: 全パターンをインポート
        if (data.allPatterns) {
          this.patternManager.importAllPatterns(data.allPatterns);
          this.loadPatternFromManager();
        } 
        // 旧フォーマット対応
        else if (data.grid) {
          if (this.uiManager.setAllPageData && Array.isArray(data.grid) && Array.isArray(data.grid[0]) && Array.isArray(data.grid[0][0])) {
            this.uiManager.setAllPageData(data.grid, data.noteData);
          } else {
            this.uiManager.setGrid(data.grid, data.noteData);
          }
          
          if (data.parameters) {
            this.uiManager.setParameters(data.parameters);
            this.sequencer.setBPM(data.parameters.bpm);
            this.sequencer.setSwing(data.parameters.swing);
            
            if (data.parameters.decay) this.audioEngine.setDecay(data.parameters.decay / 100);
            if (data.parameters.delayTime) this.audioEngine.setDelayTime(data.parameters.delayTime / 1000);
            if (data.parameters.delayFeedback) this.audioEngine.setDelayFeedback(data.parameters.delayFeedback / 100);
            if (data.parameters.delayMix) this.audioEngine.setDelayMix(data.parameters.delayMix / 100);
          }
          
          if (data.trackSettings) {
            this.uiManager.setTrackSettings(data.trackSettings);
          }
          
          if (data.muteStates) {
            this.sequencer.muteStates = data.muteStates;
            this.updateMuteSoloButtons();
          }
          
          if (data.soloStates) {
            this.sequencer.soloStates = data.soloStates;
            this.updateMuteSoloButtons();
          }
        }
        
        // inputをリセット（同じファイルを再度読み込めるようにする）
        e.target.value = '';
        this.uiManager.showStatus(`📂 "${data.title || 'プロジェクト'}" を読み込みました`, 'success');
        
      } catch (error) {
        console.error('JSON読込エラー:', error);
        this.uiManager.showStatus('❌ JSON読込に失敗しました', 'error');
      }
    };
    
    reader.readAsText(file);
  }
  
  // LocalStorageへのデータ保存
  saveData() {
    this.saveCurrentPatternToManager();
    
    if (this.patternManager.saveToLocalStorage()) {
      this.uiManager.showStatus('💾 全パターンを保存しました！', 'success');
    } else {
      this.uiManager.showStatus('❌ 保存に失敗しました', 'error');
    }
  }
  
  // LocalStorageからのデータ読込
  loadData() {
    this.loadAllPatternsFromStorage();
    this.uiManager.showStatus('📂 保存データを読み込みました', 'success');
  }
}

// アプリ起動
window.addEventListener('DOMContentLoaded', () => {
  new BeatMakerApp();
});