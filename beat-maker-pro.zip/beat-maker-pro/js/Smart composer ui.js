// ==========================================
// スマート作曲UI
// ==========================================

class SmartComposerUI {
  constructor(smartComposer) {
    this.composer = smartComposer;
    this.containerId = 'smart-composer-container'; // HTMLで作成したIDを指定
  }
  
  // UIを生成
  createUI() {
    // コンテナを探す
    const container = document.getElementById(this.containerId);
    
    // コンテナが見つからない場合は、controlsにフォールバック（安全策）
    const targetElement = container || document.getElementById('controls');
    
    if (!targetElement) {
      console.error('SmartComposerUI: 表示先のコンテナが見つかりません');
      return;
    }
    
    // UIのHTML構築
    const uiContent = `
      <div class="smart-composer-wrapper">
        <h3 class="smart-composer-title">🎼 スマート作曲システム</h3>
        <p class="smart-composer-description">
          感情とジャンルを選んで、AIが自動でメロディとリズムを生成します
        </p>
        
        <div class="emotion-parameters">
          <h4 class="param-section-title">💭 感情パラメータ</h4>
          
          <div class="emotion-param-item">
            <label class="emotion-param-label">
              <span class="param-icon">💕</span>
              やさしさ
              <span class="emotion-param-value" id="composer-gentleness-value">50</span>
            </label>
            <input type="range" id="composer-gentleness" 
                   class="emotion-param-slider" 
                   min="0" max="100" value="50" step="1">
            <div class="param-description">
              激しい <span style="flex-grow:1"></span> やさしい
            </div>
          </div>
          
          <div class="emotion-param-item">
            <label class="emotion-param-label">
              <span class="param-icon">🌑</span>
              暗さ
              <span class="emotion-param-value" id="composer-darkness-value">50</span>
            </label>
            <input type="range" id="composer-darkness" 
                   class="emotion-param-slider" 
                   min="0" max="100" value="50" step="1">
            <div class="param-description">
              明るい <span style="flex-grow:1"></span> 暗い
            </div>
          </div>
          
          <div class="emotion-param-item">
            <label class="emotion-param-label">
              <span class="param-icon">🌸</span>
              はかなさ
              <span class="emotion-param-value" id="composer-ephemerality-value">50</span>
            </label>
            <input type="range" id="composer-ephemerality" 
                   class="emotion-param-slider" 
                   min="0" max="100" value="50" step="1">
            <div class="param-description">
              安定的 <span style="flex-grow:1"></span> はかない
            </div>
          </div>
        </div>
        
        <div class="genre-selection">
          <h4 class="param-section-title">🎸 ジャンル選択</h4>
          <div class="genre-buttons">
            <button class="genre-btn active" data-genre="pop">
              <span class="genre-emoji">🎵</span> Pop
            </button>
            <button class="genre-btn" data-genre="rock">
              <span class="genre-emoji">🎸</span> Rock
            </button>
            <button class="genre-btn" data-genre="bossanova">
              <span class="genre-emoji">🌴</span> Bossa
            </button>
            <button class="genre-btn" data-genre="jazz">
              <span class="genre-emoji">🎷</span> Jazz
            </button>
            <button class="genre-btn" data-genre="ambient">
              <span class="genre-emoji">🌊</span> Ambient
            </button>
            <button class="genre-btn" data-genre="electronic">
              <span class="genre-emoji">⚡</span> Electro
            </button>
          </div>
        </div>
        
        <div class="emotion-presets">
          <h4 class="param-section-title">⚡ プリセット</h4>
          <div class="preset-buttons">
            <button class="preset-btn" data-preset="gentle">💕 やさしい</button>
            <button class="preset-btn" data-preset="dark">🌑 暗い</button>
            <button class="preset-btn" data-preset="ephemeral">🌸 はかない</button>
            <button class="preset-btn" data-preset="balanced">⚖️ 標準</button>
          </div>
        </div>

        <div class="compose-actions">
          <button id="smart-compose-btn" class="smart-compose-button">
            ✨ 曲を生成する
          </button>
        </div>
      </div>
    `;
    
    // HTMLを挿入
    targetElement.innerHTML = uiContent;
    
    // イベントリスナーを設定
    this.setupEventListeners();
  }
  
  // イベントリスナー設定
  setupEventListeners() {
    // 感情パラメータスライダー
    this._attachSliderListener('composer-gentleness', 'gentleness');
    this._attachSliderListener('composer-darkness', 'darkness');
    this._attachSliderListener('composer-ephemerality', 'ephemerality');
    
    // ジャンルボタン
    document.querySelectorAll('.genre-btn').forEach(btn => {
      btn.addEventListener('click', (e) => {
        // 全てのボタンからactiveを外す
        document.querySelectorAll('.genre-btn').forEach(b => b.classList.remove('active'));
        // クリックされたボタンにactiveをつける
        e.currentTarget.classList.add('active');
        
        const genre = e.currentTarget.dataset.genre;
        if(this.composer && typeof this.composer.setGenre === 'function') {
            this.composer.setGenre(genre);
        }
      });
    });
    
    // 作曲ボタン
    document.getElementById('smart-compose-btn')?.addEventListener('click', () => {
        if(this.composer && typeof this.composer.compose === 'function') {
            // ローディングエフェクトなどを入れるとなお良し
            this.composer.compose();
        } else {
            console.error("Composer logic is missing");
        }
    });
    
    // プリセットボタン
    document.querySelectorAll('.preset-btn').forEach(btn => {
      btn.addEventListener('click', (e) => {
        const preset = e.currentTarget.dataset.preset;
        this.applyPreset(preset);
      });
    });
  }

  // スライダー用ヘルパー関数
  _attachSliderListener(id, property) {
      const slider = document.getElementById(id);
      const display = document.getElementById(`${id}-value`);
      
      if (slider) {
          slider.addEventListener('input', (e) => {
              const value = parseInt(e.target.value);
              if (display) display.textContent = value;
              // コンポーザーのプロパティを更新
              if (this.composer) {
                  this.composer[property] = value;
              }
          });
      }
  }
  
  // プリセット適用
  applyPreset(preset) {
    const presets = {
      gentle: { gentleness: 90, darkness: 20, ephemerality: 40 },
      dark: { gentleness: 30, darkness: 90, ephemerality: 50 },
      ephemeral: { gentleness: 70, darkness: 40, ephemerality: 90 },
      balanced: { gentleness: 50, darkness: 50, ephemerality: 50 }
    };
    
    const values = presets[preset];
    if (!values) return;
    
    // スライダーと数値を更新
    this.setEmotionSliders(values.gentleness, values.darkness, values.ephemerality);
    
    // Composerのパラメータ更新
    if (this.composer) {
        if (typeof this.composer.setEmotion === 'function') {
            this.composer.setEmotion(values.gentleness, values.darkness, values.ephemerality);
        } else {
            // メソッドがない場合はプロパティ直接代入
            this.composer.gentleness = values.gentleness;
            this.composer.darkness = values.darkness;
            this.composer.ephemerality = values.ephemerality;
        }
        
        // プリセット選択後、即座に作曲するかどうかはお好みで（ここではしない）
        // this.composer.compose(); 
    }
  }
  
  // 感情スライダーを設定
  setEmotionSliders(gentleness, darkness, ephemerality) {
    const updateSlider = (id, val) => {
        const slider = document.getElementById(id);
        const display = document.getElementById(`${id}-value`);
        if(slider) slider.value = val;
        if(display) display.textContent = val;
    };

    updateSlider('composer-gentleness', gentleness);
    updateSlider('composer-darkness', darkness);
    updateSlider('composer-ephemerality', ephemerality);
  }
}

// 重要: これがないと他のファイルからクラスを使えません
window.SmartComposerUI = SmartComposerUI;